package com.smartstock.data;

import android.content.Context;
import android.os.Looper;
import android.view.inputmethod.EditorInfo;

import androidx.appcompat.app.AlertDialog;
import androidx.test.core.app.ApplicationProvider;

import com.smartstock.core.Field;
import com.smartstock.core.TestUtil;
import com.smartstock.core.XlsxImporter;
import com.smartstock.core.XlsxPackage;
import com.smartstock.ui.CountActivity;
import com.smartstock.ui.UiFlowShots;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;
import org.robolectric.annotation.LooperMode;
import org.robolectric.shadows.ShadowDialog;

import java.io.File;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import static org.junit.Assert.*;
import static org.robolectric.Shadows.shadowOf;

/** Items found during counting that are not in the Excel file. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34, qualifiers = "ar-w412dp-h915dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
public class AddItemTest {
    Context ctx;
    Repository repo;

    @Before public void setUp() {
        ctx = ApplicationProvider.getApplicationContext();
        Db.reset();
        ctx.deleteDatabase(Db.NAME);
        ctx.getSharedPreferences(Settings.FILE, 0).edit().clear().commit();
        Settings.setSound(ctx, false);
        repo = new Repository(Db.get(ctx));
    }

    @After public void tearDown() { Db.reset(); }

    static String tok() { return UUID.randomUUID().toString(); }

    long session(String fixture) throws Exception {
        File staged = TestUtil.fixture(fixture);
        XlsxImporter.Result r;
        try (XlsxPackage pkg = new XlsxPackage(staged, Workflows.PARSER)) {
            XlsxImporter.HeaderScan h = XlsxImporter.scanHeader(pkg, pkg.defaultSheet());
            r = XlsxImporter.read(pkg, pkg.defaultSheet(), h.headerRow, h.match.map, h.headers, null);
        }
        Repository.SessionDraft d = new Repository.SessionDraft();
        d.name = "s"; d.countDate = "2026-11-25"; d.fileName = fixture;
        return Workflows.createSession(ctx, staged, r, d, null);
    }

    static Models.NewItem item(String g, String n, String u, String p, String b, String qty, String cost) {
        Models.NewItem x = new Models.NewItem();
        x.group = g; x.name = n; x.unit = u; x.pack = p; x.barcode = b; x.qty = new BigDecimal(qty); x.cost = new BigDecimal(cost);
        return x;
    }

    static XlsxImporter.Result reimport(File f) throws Exception {
        try (XlsxPackage pkg = new XlsxPackage(f, Workflows.PARSER)) {
            XlsxImporter.HeaderScan h = XlsxImporter.scanHeader(pkg, pkg.defaultSheet());
            return XlsxImporter.read(pkg, pkg.defaultSheet(), h.headerRow, h.match.map, h.headers, null);
        }
    }

    @Test public void addedItemsAreCountedLoggedAndExportedAsNewRows() throws Exception {
        long sid = session("f10_multisheet.xlsx");          // has 60 prepared, formatted empty rows after the data
        Models.NewItem ni = item("عطور", "عطر جديد غير مسجل", "زجاجة", "1", "0099887766", "5", "2.5");
        ni.expiry = "2028-03-15";
        Models.SaveResult a = repo.addNewItem(sid, ni, tok());
        assertEquals("2028-03-15", a.item.expiry);
        assertEquals("2027-08-01", repo.findByBarcode(sid, "4600").get(0).expiry);   // read from the file
        assertEquals(Models.SaveResult.Kind.OK, a.kind);
        assertTrue(a.item.added);
        assertTrue(a.item.counted);
        assertEquals("ADD", a.op.type);
        Models.SaveResult b = repo.addNewItem(sid, item("", "صنف بلا باركود", "", "", "", "3", "10"), tok());
        assertEquals(Models.SaveResult.Kind.OK, b.kind);
        // second count of an added item accumulates like any item
        repo.addCount(a.item.id, new BigDecimal(2), tok());
        repo.addCount(repo.findByBarcode(sid, "4600").get(0).id, new BigDecimal(20), tok());
        Models.Stats st = repo.stats(sid);
        assertEquals(11, st.items);
        assertEquals(2, st.added);
        assertEquals(0, st.sumValue.compareTo(new BigDecimal("557.5")));   // 20*25.5 + 7*2.5 + 3*10
        // found again by its barcode, with leading zeros kept
        assertEquals("عطر جديد غير مسجل", repo.findByBarcode(sid, "0099887766").get(0).name);
        assertEquals(2, repo.count(sid, null, Models.Filter.ADDED, null));

        Workflows.ExportReport rep = Workflows.exportVerified(ctx, sid);     // verifies every row incl. new ones
        assertEquals(11, rep.rows);
        String out = System.getProperty("smartstock.out", "");
        if (!out.isEmpty()) Backup.copyFile(rep.file, new File(out, "SMART_STOCK_SAMPLE_OUTPUT_WITH_ADDED.xlsx"));
        XlsxImporter.Result r = reimport(rep.file);
        assertEquals(11, r.rows.size());
        XlsxImporter.Row last = r.rows.get(9), last2 = r.rows.get(10);
        assertEquals(12, last.rowNum);                    // first prepared empty row right after the last item (row 11)
        assertEquals(13, last2.rowNum);
        assertEquals("عطور", last.group);
        assertEquals("عطر جديد غير مسجل", last.name);
        assertEquals("زجاجة", last.unit);
        assertEquals("1", last.pack);
        assertEquals("0099887766", last.barcode);
        assertEquals(0, last.fileQty.compareTo(new BigDecimal(7)));
        assertEquals(0, last.cost.compareTo(new BigDecimal("2.5")));
        assertEquals("2028-03-15", last.expiry);                    // written as a real Excel date (date style of the column)
        assertEquals("صنف بلا باركود", last2.name);
        assertEquals(1, r.emptyRowsInside);               // the original blank row 7 is still the only gap
        String sheet = TestUtil.entry(rep.file, "xl/worksheets/sheet3.xml");
        assertTrue(sheet, sheet.contains("<c r=\"K12\""));  // total column for the new row
        assertTrue(sheet.contains("17.5"));                 // 7 x 2.5
    }

    @Test public void reorderedColumnsWithoutPreparedRows() throws Exception {
        long sid = session("f_single_reordered.xlsx");       // 20 items, last data row 21, nothing after it
        Models.Session s = repo.session(sid);
        // the form shows the fields in the file's column order
        List<Field> order = com.smartstock.ui.NewItemDialogAccess.ordered(s);
        assertEquals(java.util.Arrays.asList(Field.BARCODE, Field.COST, Field.NAME, Field.QTY, Field.PACK, Field.GROUP, Field.UNIT), order);
        repo.addNewItem(sid, item("مجموعة 9", "صنف 21 جديد", "قطعة", "حبة", "8000000000099", "4", "1.75"), tok());
        Workflows.ExportReport rep = Workflows.exportVerified(ctx, sid);
        XlsxImporter.Result r = reimport(rep.file);
        assertEquals(21, r.rows.size());
        XlsxImporter.Row n = r.rows.get(20);
        assertEquals(22, n.rowNum);
        assertEquals("صنف 21 جديد", n.name);
        assertEquals("8000000000099", n.barcode);
        assertEquals("مجموعة 9", n.group);
        assertEquals(0, n.fileQty.compareTo(new BigDecimal(4)));
        assertEquals(Integer.valueOf(5), r.map.get(Field.TOTAL));
        assertTrue(TestUtil.entry(rep.file, r.sheetPath).contains("<v>7</v>"));   // 4 x 1.75
    }

    @Test public void undoEditDeleteAndValidation() throws Exception {
        long sid = session("f10_multisheet.xlsx");
        assertEquals(Models.SaveResult.Kind.INVALID, repo.addNewItem(sid, item("", "", "", "", "1", "1", "1"), tok()).kind);
        assertEquals(Models.SaveResult.Kind.INVALID, repo.addNewItem(sid, item("", "x", "", "", "1", "-1", "1"), tok()).kind);
        assertEquals(Models.SaveResult.Kind.INVALID, repo.addNewItem(sid, item("", "x", "", "", "1", "1.5", "1"), tok()).kind); // no decimals in session
        String t = tok();
        Models.SaveResult a = repo.addNewItem(sid, item("", "جديد", "", "", "555", "4", "3"), t);
        assertEquals(Models.SaveResult.Kind.DUPLICATE, repo.addNewItem(sid, item("", "جديد", "", "", "555", "4", "3"), t).kind);
        assertEquals(10, repo.stats(sid).items);
        // edit (name/cost) of an added item; imported items are refused
        Models.NewItem e = item("ع", "جديد معدل", "ق", "1", "556", "0", "3.5");
        assertEquals(Models.SaveResult.Kind.OK, repo.updateAddedItem(a.item.id, e).kind);
        assertEquals(0, repo.item(a.item.id).total().compareTo(new BigDecimal(14)));
        assertEquals(Models.SaveResult.Kind.INVALID, repo.updateAddedItem(repo.findByBarcode(sid, "4600").get(0).id, e).kind);
        // undo the add-count -> item stays but becomes not counted
        repo.undo(repo.lastUndoable(sid).id, tok());
        assertFalse(repo.item(a.item.id).counted);
        // delete
        assertEquals(Models.SaveResult.Kind.OK, repo.deleteAddedItem(a.item.id).kind);
        assertNull(repo.item(a.item.id));
        assertEquals(9, repo.stats(sid).items);
        assertEquals(9, repo.session(sid).itemCount);
        assertEquals(Models.SaveResult.Kind.INVALID, repo.deleteAddedItem(repo.findByBarcode(sid, "4600").get(0).id).kind);
        // backup / restore keeps added items
        repo.addNewItem(sid, item("", "باق", "", "", "777", "2", "5"), tok());
        File bk = new File(ctx.getCacheDir(), "bk.zip");
        try (java.io.FileOutputStream o = new java.io.FileOutputStream(bk)) { Backup.create(ctx, o, "t"); }
        Backup.apply(ctx, Backup.validate(ctx, bk), "t");
        repo = new Repository(Db.get(ctx));
        assertTrue(repo.findByBarcode(sid, "777").get(0).added);
    }

    static void flush() throws Exception {
        for (int i = 0; i < 6; i++) { UiFlowShots.drain(); shadowOf(Looper.getMainLooper()).idle(); }
    }

    @Test public void unknownBarcodeOpensAddFormOnCountScreen() throws Exception {
        long sid = session("f10_multisheet.xlsx");
        Settings.setActiveSession(ctx, sid);
        CountActivity a = Robolectric.buildActivity(CountActivity.class).setup().get();
        flush();
        com.smartstock.ui.CountAccess.code(a).setText("6299999999999");
        com.smartstock.ui.CountAccess.code(a).onEditorAction(EditorInfo.IME_ACTION_SEARCH);
        flush();
        AlertDialog nf = (AlertDialog) ShadowDialog.getLatestDialog();
        assertEquals("إضافة صنف جديد", nf.getButton(AlertDialog.BUTTON_POSITIVE).getText().toString());
        nf.getButton(AlertDialog.BUTTON_POSITIVE).performClick();
        flush();
        AlertDialog form = (AlertDialog) ShadowDialog.getLatestDialog();
        List<android.widget.EditText> edits = com.smartstock.ui.CountAccess.edits(form.getWindow().getDecorView());
        // order = file columns: المجموعة, الصنف, الوحدة, العبوة, الباركود, الكمية, التكلفة, تاريخ الانتهاء
        assertEquals(8, edits.size());
        assertEquals("6299999999999", edits.get(4).getText().toString());   // scanned barcode prefilled
        edits.get(0).setText("مكياج");
        edits.get(1).setText("ماسكرا جديدة");
        edits.get(2).setText("قطعة");
        edits.get(3).setText("حبة");
        edits.get(5).setText("6");
        edits.get(6).setText("4.25");
        edits.get(7).setText("2029-12-31");
        UiFlowShots.shotDialog(form, "14_add_new_item");
        form.getButton(AlertDialog.BUTTON_POSITIVE).performClick();
        flush();
        Models.Item it = repo.findByBarcode(sid, "6299999999999").get(0);
        assertTrue(it.added);
        assertEquals("ماسكرا جديدة", it.name);
        assertEquals(0, it.total().compareTo(new BigDecimal("25.5")));
        assertEquals("2029-12-31", it.expiry);
    }
}
