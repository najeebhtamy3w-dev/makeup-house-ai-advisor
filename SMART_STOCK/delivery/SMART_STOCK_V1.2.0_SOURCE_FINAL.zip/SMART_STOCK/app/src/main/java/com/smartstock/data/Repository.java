package com.smartstock.data;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import com.smartstock.core.ArabicText;
import com.smartstock.core.ColumnMap;
import com.smartstock.core.Num;
import com.smartstock.core.XlsxImporter;
import com.smartstock.data.Models.*;

import org.json.JSONArray;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * All database access. Every write that changes a quantity happens in ONE transaction together
 * with its operation-log row, so a quantity can never change without an audit record (and vice versa).
 * Call from a single background thread (see Bg).
 */
public final class Repository {
    private final Db helper;
    private final SQLiteDatabase raw;

    public Repository(Db helper) { this.helper = helper; this.raw = null; }

    /** For verifying a database file that is not the live one (backup restore validation). */
    public Repository(SQLiteDatabase raw) { this.helper = null; this.raw = raw; }

    SQLiteDatabase db() { return raw != null ? raw : helper.getWritableDatabase(); }

    public interface Progress { void onProgress(int done, int total); }

    // ------------------------------------------------------------------ sessions

    public static final class SessionDraft {
        public String name, shop = "", countDate, fileName, sourceFile, currency = "";
        public boolean allowDecimal;
    }

    public long createSession(SessionDraft d, XlsxImporter.Result r, String importSummary, Progress p) {
        SQLiteDatabase db = db();
        db.beginTransaction();
        try {
            ContentValues v = new ContentValues();
            v.put("name", d.name);
            v.put("shop", d.shop == null ? "" : d.shop);
            v.put("count_date", d.countDate);
            v.put("created_at", System.currentTimeMillis());
            v.put("status", "ACTIVE");
            v.put("file_name", d.fileName);
            v.put("source_file", d.sourceFile);
            v.put("sheet_name", r.sheetName);
            v.put("sheet_path", r.sheetPath);
            v.put("header_row", r.headerRow);
            v.put("col_map", r.map.serialize());
            JSONArray h = new JSONArray();
            for (String s : r.headers) h.put(s == null ? "" : s);
            v.put("headers", h.toString());
            boolean created = !r.map.has(com.smartstock.core.Field.TOTAL);
            v.put("total_col", created ? r.maxColumn + 1 : r.map.get(com.smartstock.core.Field.TOTAL));
            v.put("total_created", created ? 1 : 0);
            v.put("allow_decimal", d.allowDecimal ? 1 : 0);
            v.put("currency", d.currency == null ? "" : d.currency);
            v.put("item_count", r.rows.size());
            v.put("import_summary", importSummary == null ? "" : importSummary);
            long sid = db.insertOrThrow("sessions", null, v);
            SQLiteStatement st = db.compileStatement("INSERT INTO items(session_id,seq,row_num,grp,name,unit,pack,barcode,barcode_key,name_norm,cost,cost_issue,qty,counted) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'0',0)");
            int i = 0, n = r.rows.size();
            for (XlsxImporter.Row row : r.rows) {
                st.clearBindings();
                st.bindLong(1, sid);
                st.bindLong(2, i);
                st.bindLong(3, row.rowNum);
                st.bindString(4, row.group);
                st.bindString(5, row.name);
                st.bindString(6, row.unit);
                st.bindString(7, row.pack);
                st.bindString(8, row.barcode);
                st.bindString(9, barcodeKey(row.barcode));
                st.bindString(10, ArabicText.norm(row.name));
                if (row.cost == null) st.bindNull(11); else st.bindString(11, Num.plain(row.cost));
                if (row.costIssue == null) st.bindNull(12); else st.bindString(12, row.costIssue);
                st.executeInsert();
                i++;
                if (p != null && i % 1000 == 0) p.onProgress(i, n);
            }
            db.setTransactionSuccessful();
            return sid;
        } finally {
            db.endTransaction();
        }
    }

    /** One exported file to merge: label + rows read from it (quantities come from the file). */
    public static final class MergeInput {
        public String label, fileName, sha256;
        public XlsxImporter.Result result;
    }

    /**
     * Creates a read-only MERGED session from several exported files (one per phone). Items keep their
     * file order; quantities and costs are taken from each file; totals are recomputed exactly.
     */
    public long createMergedSession(String name, String shop, String date, String currency, List<MergeInput> inputs, Progress p) throws Exception {
        SQLiteDatabase db = db();
        db.beginTransaction();
        try {
            int n = 0;
            for (MergeInput in : inputs) n += in.result.rows.size();
            JSONArray parts = new JSONArray();
            for (MergeInput in : inputs) {
                org.json.JSONObject o = new org.json.JSONObject();
                o.put("label", in.label); o.put("file", in.fileName); o.put("sha256", in.sha256);
                o.put("sheet", in.result.sheetName); o.put("items", in.result.rows.size());
                parts.put(o);
            }
            ContentValues v = new ContentValues();
            v.put("name", name); v.put("shop", shop == null ? "" : shop); v.put("count_date", date);
            v.put("created_at", System.currentTimeMillis()); v.put("status", "FINISHED");
            v.put("file_name", inputs.size() + " ملفات مدمجة"); v.put("source_file", "");
            v.put("sheet_name", ""); v.put("sheet_path", ""); v.put("header_row", 0); v.put("col_map", "");
            v.put("headers", "[]"); v.put("total_col", 0); v.put("total_created", 0); v.put("allow_decimal", 1);
            v.put("currency", currency == null ? "" : currency); v.put("item_count", n);
            v.put("import_summary", ""); v.put("kind", "MERGED"); v.put("parts", parts.toString());
            long sid = db.insertOrThrow("sessions", null, v);
            SQLiteStatement st = db.compileStatement("INSERT INTO items(session_id,seq,row_num,grp,name,unit,pack,barcode,barcode_key,name_norm,cost,cost_issue,qty,counted,src) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            int i = 0;
            for (MergeInput in : inputs) {
                for (XlsxImporter.Row row : in.result.rows) {
                    BigDecimal q = row.fileQty == null ? BigDecimal.ZERO : Num.strip(row.fileQty);
                    st.clearBindings();
                    st.bindLong(1, sid); st.bindLong(2, i); st.bindLong(3, row.rowNum);
                    st.bindString(4, row.group); st.bindString(5, row.name); st.bindString(6, row.unit);
                    st.bindString(7, row.pack); st.bindString(8, row.barcode); st.bindString(9, barcodeKey(row.barcode));
                    st.bindString(10, ArabicText.norm(row.name));
                    if (row.cost == null) st.bindNull(11); else st.bindString(11, Num.plain(row.cost));
                    if (row.costIssue == null) st.bindNull(12); else st.bindString(12, row.costIssue);
                    st.bindString(13, Num.plain(q));
                    st.bindLong(14, q.signum() > 0 ? 1 : 0);   // a file has no "counted" flag: quantity > 0 => counted
                    st.bindString(15, in.label);
                    st.executeInsert();
                    i++;
                    if (p != null && i % 1000 == 0) p.onProgress(i, n);
                }
            }
            db.setTransactionSuccessful();
            return sid;
        } finally {
            db.endTransaction();
        }
    }

    /** Per-source-file totals of a merged session, in file order. */
    public List<Part> parts(long sid) {
        Map<String, Part> m = new LinkedHashMap<>();
        Session s = session(sid);
        try {
            JSONArray a = new JSONArray(s.parts);
            for (int i = 0; i < a.length(); i++) {
                org.json.JSONObject o = a.getJSONObject(i);
                Part pt = new Part(); pt.label = o.getString("label"); pt.fileName = o.optString("file"); pt.sha256 = o.optString("sha256");
                m.put(pt.label, pt);
            }
        } catch (Exception ignored) {}
        try (Cursor c = db().rawQuery("SELECT src, qty, cost FROM items WHERE session_id=? ORDER BY seq", new String[]{String.valueOf(sid)})) {
            while (c.moveToNext()) {
                Part pt = m.get(c.getString(0));
                if (pt == null) { pt = new Part(); pt.label = c.getString(0); m.put(pt.label, pt); }
                pt.items++;
                String q = c.getString(1);
                if (!"0".equals(q)) {
                    pt.positive++;
                    BigDecimal qty = new BigDecimal(q);
                    pt.qty = pt.qty.add(qty);
                    if (!c.isNull(2)) pt.value = pt.value.add(qty.multiply(new BigDecimal(c.getString(2))));
                }
            }
        }
        for (Part pt : m.values()) { pt.qty = Num.strip(pt.qty); pt.value = Num.strip(pt.value); }
        return new ArrayList<>(m.values());
    }

    /** Barcodes present in more than one source file of a merged session. */
    public int crossFileDuplicateBarcodes(long sid) {
        try (Cursor c = db().rawQuery("SELECT COUNT(*) FROM (SELECT barcode FROM items WHERE session_id=? AND barcode<>'' GROUP BY barcode HAVING COUNT(DISTINCT src)>1)", new String[]{String.valueOf(sid)})) {
            c.moveToFirst();
            return c.getInt(0);
        }
    }

    boolean hasColumn(String table, String col) {
        try (Cursor c = db().rawQuery("PRAGMA table_info(" + table + ")", null)) {
            while (c.moveToNext()) if (col.equals(c.getString(1))) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ items added during counting

    /**
     * Adds an item that was not in the Excel file and records its first counted quantity — one
     * transaction (item + ADD operation). It is appended after the last item (seq) and gets its Excel
     * row only at export time.
     */
    public SaveResult addNewItem(long sid, NewItem n, String token) {
        if (n.name == null || n.name.trim().isEmpty()) return SaveResult.of(SaveResult.Kind.INVALID, "اسم الصنف مطلوب");
        if (n.cost == null || n.cost.signum() < 0) return SaveResult.of(SaveResult.Kind.INVALID, "أدخل تكلفة صحيحة (صفر أو أكثر)");
        Session s = session(sid);
        if (s == null || s.isMerged()) return SaveResult.of(SaveResult.Kind.INVALID, "لا يمكن إضافة أصناف لهذه الجلسة");
        String err = Num.validateQty(n.qty, s.allowDecimal);
        if (err != null) return SaveResult.of(SaveResult.Kind.INVALID, err);
        SQLiteDatabase db = db();
        db.beginTransaction();
        try {
            try (Cursor c = db.rawQuery("SELECT COUNT(*) FROM ops WHERE token=?", new String[]{token})) {
                c.moveToFirst();
                if (c.getInt(0) > 0) return SaveResult.of(SaveResult.Kind.DUPLICATE, "تم حفظ هذا الصنف مسبقًا");
            }
            int seq;
            try (Cursor c = db.rawQuery("SELECT COALESCE(MAX(seq),-1)+1 FROM items WHERE session_id=?", new String[]{String.valueOf(sid)})) { c.moveToFirst(); seq = c.getInt(0); }
            ContentValues v = new ContentValues();
            String barcode = ArabicText.digitsToLatin(n.barcode == null ? "" : n.barcode.trim());
            v.put("session_id", sid); v.put("seq", seq); v.put("row_num", 0);
            v.put("grp", n.group.trim()); v.put("name", n.name.trim()); v.put("unit", n.unit.trim()); v.put("pack", n.pack.trim());
            v.put("barcode", barcode); v.put("barcode_key", barcodeKey(barcode)); v.put("name_norm", ArabicText.norm(n.name));
            v.put("cost", Num.plain(n.cost)); v.put("qty", "0"); v.put("counted", 0); v.put("added", 1);
            long id = db.insertOrThrow("items", null, v);
            SaveResult r = addCount(id, n.qty, token);   // nested transaction: same atomic unit
            if (r.kind != SaveResult.Kind.OK) return r;
            ContentValues sc = new ContentValues();
            sc.put("item_count", s.itemCount + 1);
            db.update("sessions", sc, "id=?", new String[]{String.valueOf(sid)});
            db.setTransactionSuccessful();
            return r;
        } finally {
            db.endTransaction();
        }
    }

    /** Edit the descriptive fields / cost of an ADDED item (imported items stay read-only). */
    public SaveResult updateAddedItem(long itemId, NewItem n) {
        Item it = item(itemId);
        if (it == null || !it.added) return SaveResult.of(SaveResult.Kind.INVALID, "يمكن تعديل الأصناف المضافة فقط");
        if (n.name == null || n.name.trim().isEmpty()) return SaveResult.of(SaveResult.Kind.INVALID, "اسم الصنف مطلوب");
        if (n.cost == null || n.cost.signum() < 0) return SaveResult.of(SaveResult.Kind.INVALID, "أدخل تكلفة صحيحة");
        String barcode = ArabicText.digitsToLatin(n.barcode == null ? "" : n.barcode.trim());
        ContentValues v = new ContentValues();
        v.put("grp", n.group.trim()); v.put("name", n.name.trim()); v.put("unit", n.unit.trim()); v.put("pack", n.pack.trim());
        v.put("barcode", barcode); v.put("barcode_key", barcodeKey(barcode)); v.put("name_norm", ArabicText.norm(n.name));
        v.put("cost", Num.plain(n.cost));
        db().update("items", v, "id=?", new String[]{String.valueOf(itemId)});
        SaveResult r = SaveResult.of(SaveResult.Kind.OK, null);
        r.item = item(itemId);
        return r;
    }

    /** Removes an item that was ADDED by mistake (never an imported item). */
    public SaveResult deleteAddedItem(long itemId) {
        Item it = item(itemId);
        if (it == null || !it.added) return SaveResult.of(SaveResult.Kind.INVALID, "يمكن حذف الأصناف المضافة فقط");
        SQLiteDatabase db = db();
        db.beginTransaction();
        try {
            db.delete("ops", "item_id=?", new String[]{String.valueOf(itemId)});
            db.delete("items", "id=?", new String[]{String.valueOf(itemId)});
            db.execSQL("UPDATE sessions SET item_count=item_count-1 WHERE id=?", new Object[]{it.sessionId});
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        return SaveResult.of(SaveResult.Kind.OK, null);
    }

    static String barcodeKey(String b) {
        String t = ArabicText.digitsToLatin(b == null ? "" : b.trim());
        int i = 0;
        while (i < t.length() - 1 && t.charAt(i) == '0') i++;
        return t.substring(i);
    }

    public Session session(long id) {
        try (Cursor c = db().rawQuery("SELECT * FROM sessions WHERE id=?", new String[]{String.valueOf(id)})) {
            return c.moveToFirst() ? readSession(c) : null;
        }
    }

    public List<Session> sessions() {
        List<Session> out = new ArrayList<>();
        try (Cursor c = db().rawQuery("SELECT * FROM sessions ORDER BY created_at DESC", null)) {
            while (c.moveToNext()) out.add(readSession(c));
        }
        return out;
    }

    static Session readSession(Cursor c) {
        Session s = new Session();
        s.id = c.getLong(c.getColumnIndexOrThrow("id"));
        s.name = str(c, "name"); s.shop = str(c, "shop"); s.countDate = str(c, "count_date");
        s.createdAt = c.getLong(c.getColumnIndexOrThrow("created_at"));
        int fi = c.getColumnIndexOrThrow("finished_at");
        s.finishedAt = c.isNull(fi) ? null : c.getLong(fi);
        s.status = str(c, "status"); s.fileName = str(c, "file_name"); s.sourceFile = str(c, "source_file");
        s.sheetName = str(c, "sheet_name"); s.sheetPath = str(c, "sheet_path");
        s.headerRow = c.getInt(c.getColumnIndexOrThrow("header_row"));
        s.colMap = ColumnMap.parse(str(c, "col_map"));
        try {
            JSONArray a = new JSONArray(str(c, "headers"));
            for (int i = 0; i < a.length(); i++) { String h = a.optString(i, ""); s.headers.add(h.isEmpty() ? null : h); }
        } catch (Exception ignored) {}
        s.totalCol = c.getInt(c.getColumnIndexOrThrow("total_col"));
        s.totalCreated = c.getInt(c.getColumnIndexOrThrow("total_created")) == 1;
        s.allowDecimal = c.getInt(c.getColumnIndexOrThrow("allow_decimal")) == 1;
        s.currency = str(c, "currency");
        s.itemCount = c.getInt(c.getColumnIndexOrThrow("item_count"));
        s.importSummary = str(c, "import_summary");
        s.lastExport = str(c, "last_export");
        int k = c.getColumnIndex("kind");          // absent in a v1 database (old backup being validated)
        if (k >= 0 && !c.isNull(k)) s.kind = c.getString(k);
        int pa = c.getColumnIndex("parts");
        if (pa >= 0 && !c.isNull(pa)) s.parts = c.getString(pa);
        return s;
    }

    static String str(Cursor c, String col) {
        int i = c.getColumnIndexOrThrow(col);
        return c.isNull(i) ? "" : c.getString(i);
    }

    public void setStatus(long sid, String status) {
        ContentValues v = new ContentValues();
        v.put("status", status);
        if ("FINISHED".equals(status)) v.put("finished_at", System.currentTimeMillis()); else v.putNull("finished_at");
        db().update("sessions", v, "id=?", new String[]{String.valueOf(sid)});
    }

    public void updateSessionInfo(long sid, String name, String shop, String currency) {
        ContentValues v = new ContentValues();
        v.put("name", name); v.put("shop", shop); v.put("currency", currency);
        db().update("sessions", v, "id=?", new String[]{String.valueOf(sid)});
    }

    public void setLastExport(long sid, String text) {
        ContentValues v = new ContentValues();
        v.put("last_export", text);
        db().update("sessions", v, "id=?", new String[]{String.valueOf(sid)});
    }

    public void deleteSession(long sid) {
        SQLiteDatabase db = db();
        db.beginTransaction();
        try {
            String[] a = {String.valueOf(sid)};
            db.delete("ops", "session_id=?", a);
            db.delete("items", "session_id=?", a);
            db.delete("sessions", "id=?", a);
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    // ------------------------------------------------------------------ items

    static final String ITEM_COLS = "id,session_id,seq,row_num,grp,name,unit,pack,barcode,cost,cost_issue,qty,counted,updated_at,added";

    static Item readItem(Cursor c) {
        Item it = new Item();
        it.id = c.getLong(0); it.sessionId = c.getLong(1); it.seq = c.getInt(2); it.rowNum = c.getInt(3);
        it.group = c.getString(4); it.name = c.getString(5); it.unit = c.getString(6); it.pack = c.getString(7);
        it.barcode = c.getString(8);
        it.cost = c.isNull(9) ? null : new BigDecimal(c.getString(9));
        it.costIssue = c.isNull(10) ? null : c.getString(10);
        it.qty = new BigDecimal(c.getString(11));
        it.counted = c.getInt(12) == 1;
        it.updatedAt = c.isNull(13) ? null : c.getLong(13);
        it.added = c.getInt(14) == 1;
        return it;
    }

    public Item item(long id) {
        try (Cursor c = db().rawQuery("SELECT " + ITEM_COLS + " FROM items WHERE id=?", new String[]{String.valueOf(id)})) {
            return c.moveToFirst() ? readItem(c) : null;
        }
    }

    /** Exact barcode match first; then leading-zero-insensitive match (e.g. UPC-A vs EAN-13, or lost zeros). */
    public List<Item> findByBarcode(long sid, String code) {
        String t = ArabicText.digitsToLatin(code == null ? "" : code.trim());
        List<Item> out = new ArrayList<>();
        if (t.isEmpty()) return out;
        try (Cursor c = db().rawQuery("SELECT " + ITEM_COLS + " FROM items WHERE session_id=? AND barcode=? ORDER BY seq",
                new String[]{String.valueOf(sid), t})) {
            while (c.moveToNext()) out.add(readItem(c));
        }
        if (!out.isEmpty()) return out;
        String key = barcodeKey(t);
        if (key.isEmpty() || key.equals("0")) return out;
        try (Cursor c = db().rawQuery("SELECT " + ITEM_COLS + " FROM items WHERE session_id=? AND barcode_key=? ORDER BY seq",
                new String[]{String.valueOf(sid), key})) {
            while (c.moveToNext()) out.add(readItem(c));
        }
        return out;
    }

    static String likeEscape(String s) { return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_"); }

    /** Paged query used by the item list, name search, PDF and export (limit<=0 => all). */
    public List<Item> query(long sid, String text, Filter filter, String group, Sort sort, int limit, int offset) {
        StringBuilder w = new StringBuilder("session_id=?");
        List<String> args = new ArrayList<>();
        args.add(String.valueOf(sid));
        appendWhere(w, args, text, filter, group);
        String order;
        switch (sort == null ? Sort.SEQ : sort) {
            case NAME: order = "name_norm, seq"; break;
            case QTY: order = "CAST(qty AS REAL) DESC, seq"; break;            // ordering only, never used for money
            case COST: order = "cost IS NULL, CAST(cost AS REAL) DESC, seq"; break;
            case TOTAL: order = "cost IS NULL, CAST(qty AS REAL)*CAST(cost AS REAL) DESC, seq"; break;
            default: order = "seq";
        }
        String sql = "SELECT " + ITEM_COLS + " FROM items WHERE " + w + " ORDER BY " + order + (limit > 0 ? " LIMIT " + limit + " OFFSET " + offset : "");
        List<Item> out = new ArrayList<>();
        try (Cursor c = db().rawQuery(sql, args.toArray(new String[0]))) {
            while (c.moveToNext()) out.add(readItem(c));
        }
        return out;
    }

    public int count(long sid, String text, Filter filter, String group) {
        StringBuilder w = new StringBuilder("session_id=?");
        List<String> args = new ArrayList<>();
        args.add(String.valueOf(sid));
        appendWhere(w, args, text, filter, group);
        try (Cursor c = db().rawQuery("SELECT COUNT(*) FROM items WHERE " + w, args.toArray(new String[0]))) {
            c.moveToFirst();
            return c.getInt(0);
        }
    }

    static void appendWhere(StringBuilder w, List<String> args, String text, Filter filter, String group) {
        if (filter != null) switch (filter) {
            case COUNTED: w.append(" AND counted=1"); break;
            case UNCOUNTED: w.append(" AND counted=0"); break;
            case ZERO: w.append(" AND counted=1 AND qty='0'"); break;
            case POSITIVE: w.append(" AND qty<>'0'"); break;
            case ADDED: w.append(" AND added=1"); break;
            default: break;
        }
        if (group != null) { w.append(" AND grp=?"); args.add(group); }
        if (text != null && !text.trim().isEmpty()) {
            String digits = ArabicText.digitsToLatin(text.trim());
            w.append(" AND (barcode LIKE ? ESCAPE '\\'");
            args.add("%" + likeEscape(digits) + "%");
            String[] tokens = ArabicText.norm(text).split(" ");
            w.append(" OR (1=1");
            for (String tk : tokens) {
                if (tk.isEmpty()) continue;
                w.append(" AND name_norm LIKE ? ESCAPE '\\'");
                args.add("%" + likeEscape(tk) + "%");
            }
            w.append("))");
        }
    }

    public List<String> groups(long sid) {
        List<String> out = new ArrayList<>();
        try (Cursor c = db().rawQuery("SELECT grp, MIN(seq) m FROM items WHERE session_id=? GROUP BY grp ORDER BY m", new String[]{String.valueOf(sid)})) {
            while (c.moveToNext()) out.add(c.getString(0));
        }
        return out;
    }

    /** Streams items in original Excel order (constant memory). */
    public interface ItemSink { void accept(Item it) throws Exception; }

    public void forEach(long sid, Filter filter, String group, ItemSink sink) throws Exception {
        StringBuilder w = new StringBuilder("session_id=?");
        List<String> args = new ArrayList<>();
        args.add(String.valueOf(sid));
        appendWhere(w, args, null, filter, group);
        try (Cursor c = db().rawQuery("SELECT " + ITEM_COLS + " FROM items WHERE " + w + " ORDER BY seq", args.toArray(new String[0]))) {
            while (c.moveToNext()) sink.accept(readItem(c));
        }
    }

    // ------------------------------------------------------------------ statistics (exact)

    public Stats stats(long sid) { return stats(sid, null, null); }

    public Stats stats(long sid, Filter filter, String group) {
        Stats s = new Stats();
        StringBuilder w = new StringBuilder("session_id=?");
        List<String> args = new ArrayList<>();
        args.add(String.valueOf(sid));
        appendWhere(w, args, null, filter, group);
        boolean hasAdded = hasColumn("items", "added");     // false only for an old backup being validated
        try (Cursor c = db().rawQuery("SELECT qty, cost, counted" + (hasAdded ? ", added" : ", 0") + " FROM items WHERE " + w, args.toArray(new String[0]))) {
            while (c.moveToNext()) {
                s.items++;
                if (c.getInt(3) == 1) s.added++;
                boolean counted = c.getInt(2) == 1;
                String q = c.getString(0);
                boolean costNull = c.isNull(1);
                if (costNull) s.invalidCost++;
                if (counted) { s.counted++; if ("0".equals(q)) s.countedZero++; }
                if (!"0".equals(q)) {
                    s.positive++;
                    BigDecimal qty = new BigDecimal(q);
                    s.sumQty = s.sumQty.add(qty);
                    if (costNull) s.valuedMissing++;
                    else s.sumValue = s.sumValue.add(qty.multiply(new BigDecimal(c.getString(1))));
                }
            }
        }
        s.uncounted = s.items - s.counted;
        s.sumQty = Num.strip(s.sumQty);
        s.sumValue = Num.strip(s.sumValue);
        return s;
    }

    public List<GroupStat> groupStats(long sid) {
        Map<String, GroupStat> m = new LinkedHashMap<>();
        try (Cursor c = db().rawQuery("SELECT grp, qty, cost, counted FROM items WHERE session_id=? ORDER BY seq", new String[]{String.valueOf(sid)})) {
            while (c.moveToNext()) {
                String g = c.getString(0);
                GroupStat gs = m.get(g);
                if (gs == null) { gs = new GroupStat(); gs.group = g; m.put(g, gs); }
                gs.items++;
                if (c.getInt(3) == 1) gs.counted++;
                String q = c.getString(1);
                if (!"0".equals(q)) {
                    BigDecimal qty = new BigDecimal(q);
                    gs.qty = gs.qty.add(qty);
                    if (!c.isNull(2)) gs.value = gs.value.add(qty.multiply(new BigDecimal(c.getString(2))));
                }
            }
        }
        return new ArrayList<>(m.values());
    }

    // ------------------------------------------------------------------ counting operations

    /** Cumulative add: new qty = previous + input. Atomic with its log row; token makes it idempotent. */
    public SaveResult addCount(long itemId, BigDecimal input, String token) {
        return apply(itemId, "ADD", input, null, token, true);
    }

    /** Correction: sets the cumulative quantity to an exact value (reason is logged). */
    public SaveResult correct(long itemId, BigDecimal newQty, String reason, String token) {
        return apply(itemId, "CORRECT", newQty, reason, token, false);
    }

    private SaveResult apply(long itemId, String type, BigDecimal input, String reason, String token, boolean additive) {
        if (token == null || token.isEmpty()) return SaveResult.of(SaveResult.Kind.INVALID, "رمز العملية مفقود");
        SQLiteDatabase db = db();
        db.beginTransaction();
        try {
            Item it = item(itemId);
            if (it == null) return SaveResult.of(SaveResult.Kind.NOT_FOUND, "الصنف غير موجود");
            Session s = session(it.sessionId);
            String err = Num.validateQty(input, s.allowDecimal);
            if (err != null) return SaveResult.of(SaveResult.Kind.INVALID, err);
            BigDecimal newQty = Num.strip(additive ? it.qty.add(input) : input);
            err = Num.validateQty(newQty, s.allowDecimal);
            if (err != null) return SaveResult.of(SaveResult.Kind.INVALID, "الكمية الناتجة غير صالحة: " + err);
            if (!additive && it.counted && newQty.compareTo(it.qty) == 0)
                return SaveResult.of(SaveResult.Kind.NOTHING, "الكمية المصححة تساوي الكمية الحالية");
            long now = System.currentTimeMillis();
            ContentValues op = new ContentValues();
            op.put("session_id", it.sessionId);
            op.put("item_id", it.id);
            op.put("barcode", it.barcode);
            op.put("ts", now);
            op.put("type", type);
            op.put("prev_qty", Num.plain(it.qty));
            op.put("input_qty", Num.plain(input));
            op.put("new_qty", Num.plain(newQty));
            op.put("prev_counted", it.counted ? 1 : 0);
            if (reason != null) op.put("reason", reason);
            op.put("token", token);
            long opId;
            try {
                opId = db.insertOrThrow("ops", null, op);
            } catch (SQLiteConstraintException dup) {
                SaveResult r = SaveResult.of(SaveResult.Kind.DUPLICATE, "تم حفظ هذه العملية مسبقًا");
                r.item = it;
                return r;
            }
            ContentValues v = new ContentValues();
            v.put("qty", Num.plain(newQty));
            v.put("counted", 1);
            v.put("updated_at", now);
            db.update("items", v, "id=?", new String[]{String.valueOf(it.id)});
            db.setTransactionSuccessful();
            SaveResult r = SaveResult.of(SaveResult.Kind.OK, null);
            it.qty = newQty; it.counted = true; it.updatedAt = now;
            r.item = it;
            r.op = op(opId);
            return r;
        } finally {
            db.endTransaction();
        }
    }

    /** The most recent operation that can be undone (not an UNDO itself, not already undone). */
    public Op lastUndoable(long sid) {
        try (Cursor c = db().rawQuery(OP_SELECT + " WHERE o.session_id=? AND o.type<>'UNDO' AND o.undone=0 ORDER BY o.id DESC LIMIT 1",
                new String[]{String.valueOf(sid)})) {
            return c.moveToFirst() ? readOp(c) : null;
        }
    }

    /**
     * Safe undo: never deletes history. Writes an UNDO operation linked to the original and restores
     * the item's previous quantity and counted-state, only if the item was not changed afterwards.
     */
    public SaveResult undo(long opId, String token) {
        SQLiteDatabase db = db();
        db.beginTransaction();
        try {
            Op o = op(opId);
            if (o == null || o.undone || "UNDO".equals(o.type)) return SaveResult.of(SaveResult.Kind.NOTHING, "لا توجد عملية قابلة للتراجع");
            try (Cursor c = db.rawQuery("SELECT COUNT(*) FROM ops WHERE item_id=? AND id>? AND undone=0 AND type<>'UNDO'", new String[]{String.valueOf(o.itemId), String.valueOf(o.id)})) {
                c.moveToFirst();
                if (c.getInt(0) > 0) return SaveResult.of(SaveResult.Kind.INVALID, "تم تعديل الصنف بعد هذه العملية؛ استخدم تصحيح الكمية");
            }
            Item it = item(o.itemId);
            if (it.qty.compareTo(o.newQty) != 0) return SaveResult.of(SaveResult.Kind.INVALID, "الكمية الحالية لا تطابق العملية");
            long now = System.currentTimeMillis();
            ContentValues u = new ContentValues();
            u.put("session_id", o.sessionId);
            u.put("item_id", o.itemId);
            u.put("barcode", o.barcode);
            u.put("ts", now);
            u.put("type", "UNDO");
            u.put("prev_qty", Num.plain(it.qty));
            u.put("input_qty", Num.plain(o.inputQty));
            u.put("new_qty", Num.plain(o.prevQty));
            u.put("prev_counted", it.counted ? 1 : 0);
            u.put("reason", "تراجع عن العملية رقم " + o.id);
            u.put("ref_op_id", o.id);
            u.put("token", token);
            long id;
            try { id = db.insertOrThrow("ops", null, u); }
            catch (SQLiteConstraintException dup) { return SaveResult.of(SaveResult.Kind.DUPLICATE, "تم تنفيذ التراجع مسبقًا"); }
            ContentValues done = new ContentValues();
            done.put("undone", 1);
            db.update("ops", done, "id=?", new String[]{String.valueOf(o.id)});
            ContentValues v = new ContentValues();
            v.put("qty", Num.plain(o.prevQty));
            v.put("counted", o.prevCounted ? 1 : 0);
            v.put("updated_at", now);
            db.update("items", v, "id=?", new String[]{String.valueOf(o.itemId)});
            db.setTransactionSuccessful();
            SaveResult r = SaveResult.of(SaveResult.Kind.OK, null);
            r.item = item(o.itemId);
            r.op = op(id);
            return r;
        } finally {
            db.endTransaction();
        }
    }

    static final String OP_SELECT = "SELECT o.id,o.session_id,o.item_id,o.barcode,o.ts,o.type,o.prev_qty,o.input_qty,o.new_qty,o.prev_counted,o.reason,o.ref_op_id,o.undone,i.name FROM ops o LEFT JOIN items i ON i.id=o.item_id";

    static Op readOp(Cursor c) {
        Op o = new Op();
        o.id = c.getLong(0); o.sessionId = c.getLong(1); o.itemId = c.getLong(2); o.barcode = c.getString(3);
        o.ts = c.getLong(4); o.type = c.getString(5);
        o.prevQty = new BigDecimal(c.getString(6)); o.inputQty = new BigDecimal(c.getString(7)); o.newQty = new BigDecimal(c.getString(8));
        o.prevCounted = c.getInt(9) == 1; o.reason = c.isNull(10) ? null : c.getString(10);
        o.refOpId = c.isNull(11) ? null : c.getLong(11); o.undone = c.getInt(12) == 1; o.itemName = c.getString(13);
        return o;
    }

    public Op op(long id) {
        try (Cursor c = db().rawQuery(OP_SELECT + " WHERE o.id=?", new String[]{String.valueOf(id)})) {
            return c.moveToFirst() ? readOp(c) : null;
        }
    }

    public List<Op> ops(long sid, Long itemId, int limit) {
        List<Op> out = new ArrayList<>();
        String sql = OP_SELECT + " WHERE o.session_id=?" + (itemId != null ? " AND o.item_id=?" : "") + " ORDER BY o.id DESC LIMIT " + limit;
        String[] a = itemId != null ? new String[]{String.valueOf(sid), String.valueOf(itemId)} : new String[]{String.valueOf(sid)};
        try (Cursor c = db().rawQuery(sql, a)) {
            while (c.moveToNext()) out.add(readOp(c));
        }
        return out;
    }

    public int opCount(long sid) {
        try (Cursor c = db().rawQuery("SELECT COUNT(*) FROM ops WHERE session_id=?", new String[]{String.valueOf(sid)})) {
            c.moveToFirst();
            return c.getInt(0);
        }
    }

    /** Integrity self-check: replaying the log must reproduce each item's quantity. Returns mismatching item count. */
    public int verifyLog(long sid) {
        int bad = 0;
        try (Cursor c = db().rawQuery("SELECT i.id, i.qty, (SELECT o.new_qty FROM ops o WHERE o.item_id=i.id ORDER BY o.id DESC LIMIT 1) FROM items i WHERE i.session_id=? AND i.counted=1",
                new String[]{String.valueOf(sid)})) {
            while (c.moveToNext()) {
                if (c.isNull(2) || new BigDecimal(c.getString(1)).compareTo(new BigDecimal(c.getString(2))) != 0) bad++;
            }
        }
        return bad;
    }
}
