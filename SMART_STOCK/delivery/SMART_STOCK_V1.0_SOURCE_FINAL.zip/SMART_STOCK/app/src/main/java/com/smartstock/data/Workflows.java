package com.smartstock.data;

import android.content.Context;

import com.smartstock.core.ColumnMap;
import com.smartstock.core.ExportVerifier;
import com.smartstock.core.Field;
import com.smartstock.core.Num;
import com.smartstock.core.XlsxExporter;
import com.smartstock.core.XlsxImporter;
import com.smartstock.core.XlsxPackage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Import-to-session and verified export, shared by the UI and the automated tests. */
public final class Workflows {
    private Workflows() {}

    public static final XlsxPackage.ParserFactory PARSER = android.util.Xml::newPullParser;

    public static File sourcesDir(Context c) {
        File d = new File(c.getFilesDir(), "sources");
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return d;
    }

    /** Copies an incoming stream to a private staging file (the original document is never modified). */
    public static File stage(Context c, InputStream in) throws IOException {
        File f = new File(c.getCacheDir(), "incoming_" + UUID.randomUUID() + ".xlsx");
        try (InputStream s = in; OutputStream o = new FileOutputStream(f)) {
            byte[] b = new byte[1 << 16]; int n;
            while ((n = s.read(b)) > 0) o.write(b, 0, n);
        }
        return f;
    }

    public static String summaryText(XlsxImporter.Result r, String fileName) {
        StringBuilder b = new StringBuilder();
        b.append("اسم الملف: ").append(fileName).append('\n');
        b.append("اسم الورقة: ").append(r.sheetName).append('\n');
        b.append("صف العناوين: ").append(r.headerRow).append('\n');
        b.append("عدد الأصناف: ").append(r.rows.size()).append('\n');
        b.append("الصفوف الفارغة بين الأصناف: ").append(r.emptyRowsInside).append('\n');
        if (r.trailingEmptyRows > 0) b.append("صفوف مجهزة فارغة في نهاية الورقة (تم تجاهلها): ").append(r.trailingEmptyRows).append('\n');
        b.append("الباركودات المكررة: ").append(r.duplicateBarcodeValues).append(" باركود في ").append(r.duplicateBarcodeRows).append(" صف\n");
        b.append("أصناف بدون باركود: ").append(r.noBarcode).append('\n');
        b.append("تكاليف غير صالحة: ").append(r.invalidCost).append('\n');
        b.append("كميات غير صالحة: ").append(r.invalidQty).append('\n');
        if (r.formulaCosts > 0) b.append("تكاليف من معادلات (استُخدمت قيمها المحسوبة): ").append(r.formulaCosts).append('\n');
        if (r.skippedErrorRows > 0) b.append("صفوف أخطاء معادلات بدون بيانات (تم تجاهلها): ").append(r.skippedErrorRows).append('\n');
        if (r.skippedIncompleteRows > 0) b.append("صفوف بدون اسم وباركود (تم تجاهلها): ").append(r.skippedIncompleteRows).append('\n');
        b.append("عمود الإجمالي: ").append(r.map.has(Field.TOTAL) ? "موجود (" + ColumnMap.colLetters(r.map.get(Field.TOTAL)) + ")" : "سيُنشأ في العمود " + ColumnMap.colLetters(r.maxColumn + 1));
        return b.toString();
    }

    /** Moves the staged workbook into private storage and creates the session (single transaction). */
    public static long createSession(Context c, File staged, XlsxImporter.Result r, Repository.SessionDraft d, Repository.Progress p) throws IOException {
        String rel = "sources/" + UUID.randomUUID() + ".xlsx";
        File dest = new File(c.getFilesDir(), rel);
        Backup.copyFile(staged, dest);
        d.sourceFile = rel;
        try {
            return new Repository(Db.get(c)).createSession(d, r, summaryText(r, d.fileName), p);
        } catch (RuntimeException e) {
            //noinspection ResultOfMethodCallIgnored
            dest.delete();
            throw e;
        }
    }

    public static final class ExportReport {
        public File file; public int rows; public BigDecimal sumQty, sumValue; public Models.Stats stats; public int formulasRemoved;
    }

    /**
     * Writes the export to a private temp file, re-opens it and verifies every item row against the
     * database, checks that the file totals equal the database totals, and only then returns it.
     */
    public static ExportReport exportVerified(Context c, long sid) throws Exception {
        Repository repo = new Repository(Db.get(c));
        Models.Session s = repo.session(sid);
        File src = new File(c.getFilesDir(), s.sourceFile);
        if (!src.exists()) throw new IOException("الملف الأصلي المحفوظ للجلسة مفقود");
        XlsxExporter.Spec spec = new XlsxExporter.Spec();
        spec.sheetPath = s.sheetPath;
        spec.headerRow = s.headerRow;
        spec.qtyCol = s.colMap.get(Field.QTY);
        spec.costCol = s.colMap.get(Field.COST);
        spec.totalCol = s.totalCol;
        spec.totalColCreated = s.totalCreated;
        spec.values = new HashMap<>();
        List<ExportVerifier.Expected> expected = new ArrayList<>();
        repo.forEach(sid, null, null, it -> {
            BigDecimal total = it.total();
            spec.values.put(it.rowNum, new XlsxExporter.RowValues(it.qty, total));
            ExportVerifier.Expected e = new ExportVerifier.Expected();
            e.rowNum = it.rowNum; e.name = it.name; e.barcode = it.barcode; e.cost = it.cost; e.qty = it.qty; e.total = total;
            expected.add(e);
        });
        File out = new File(c.getCacheDir(), "export_" + sid + ".xlsx");
        XlsxExporter.Stats st;
        try (OutputStream o = new FileOutputStream(out)) { st = XlsxExporter.export(src, spec, o); }
        ColumnMap mapWithTotal = new ColumnMap(s.colMap);
        ExportVerifier.Report rep = ExportVerifier.verify(out, PARSER, s.sheetPath, s.headerRow, mapWithTotal, s.totalCol, s.headers, expected);
        if (rep.error != null) throw new IOException("فشل التحقق من الملف المصدّر: " + rep.error);
        Models.Stats stats = repo.stats(sid);
        if (rep.sumQty.compareTo(stats.sumQty) != 0 || rep.sumTotal.compareTo(stats.sumValue) != 0)
            throw new IOException("إجماليات الملف لا تطابق قاعدة البيانات");
        ExportReport r = new ExportReport();
        r.file = out; r.rows = rep.checkedRows; r.sumQty = Num.strip(rep.sumQty); r.sumValue = Num.strip(rep.sumTotal); r.stats = stats;
        r.formulasRemoved = st.formulasRemoved;
        return r;
    }

    public static void copyTo(File f, OutputStream out) throws IOException {
        try (InputStream in = new FileInputStream(f); OutputStream o = out) {
            byte[] b = new byte[1 << 16]; int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
        }
    }

    public static String safeFileName(String s) {
        String t = s == null ? "" : s.replaceAll("[\\\\/:*?\"<>|\\n\\r\\t]+", "_").trim();
        return t.isEmpty() ? "جرد" : (t.length() > 60 ? t.substring(0, 60) : t);
    }

}
