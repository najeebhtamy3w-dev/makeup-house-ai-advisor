package com.smartstock.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Looper;

import androidx.test.core.app.ApplicationProvider;

import com.smartstock.core.Num;
import com.smartstock.core.TestUtil;
import com.smartstock.core.XlsxImporter;
import com.smartstock.core.XlsxPackage;
import com.smartstock.pdf.ReportPdf;
import com.smartstock.ui.MergeActivity;
import com.smartstock.ui.PrintActivity;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;
import org.robolectric.annotation.LooperMode;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static org.junit.Assert.*;
import static org.robolectric.Shadows.shadowOf;

/** Several phones, each with different items -> exported files -> merged into one printed report. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34, qualifiers = "ar-w412dp-h915dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
public class MergeTest {
    Context ctx;
    Repository repo;

    @Before public void setUp() {
        ctx = ApplicationProvider.getApplicationContext();
        Db.reset();
        ctx.deleteDatabase(Db.NAME);
        repo = new Repository(Db.get(ctx));
    }

    @After public void tearDown() { Db.reset(); }

    static String tok() { return UUID.randomUUID().toString(); }

    long session(String fixture, String name) throws Exception {
        File staged = TestUtil.fixture(fixture);
        XlsxImporter.Result r;
        try (XlsxPackage pkg = new XlsxPackage(staged, Workflows.PARSER)) {
            XlsxImporter.HeaderScan h = XlsxImporter.scanHeader(pkg, pkg.defaultSheet());
            r = XlsxImporter.read(pkg, pkg.defaultSheet(), h.headerRow, h.match.map, h.headers, null);
        }
        Repository.SessionDraft d = new Repository.SessionDraft();
        d.name = name; d.countDate = "2026-11-25"; d.fileName = fixture;
        return Workflows.createSession(ctx, staged, r, d, null);
    }

    /** Simulates one phone: count, export the verified file, return it. */
    File phone(String fixture, String name, String[] barcodes, int[] qty, Models.Stats[] statsOut) throws Exception {
        long sid = session(fixture, name);
        for (int i = 0; i < barcodes.length; i++)
            repo.addCount(repo.findByBarcode(sid, barcodes[i]).get(0).id, new BigDecimal(qty[i]), tok());
        statsOut[0] = repo.stats(sid);
        File f = Workflows.exportVerified(ctx, sid).file;
        File copy = new File(ctx.getCacheDir(), "phone_" + sid + ".xlsx"); // host JVM paths are not UTF-8 here
        Backup.copyFile(f, copy);
        return copy;
    }

    @Test public void threePhonesMergedIntoOneReportWithGrandTotal() throws Exception {
        Models.Stats[] a = new Models.Stats[1], b = new Models.Stats[1], c = new Models.Stats[1];
        File fa = phone("f10_multisheet.xlsx", "جوال 1", new String[]{"4600", "0012345", "4600"}, new int[]{12, 100, 8}, a);
        File fb = phone("f_single_reordered.xlsx", "جوال 2", new String[]{"8000000000001", "8000000000020"}, new int[]{4, 3}, b);
        File fc = phone("f_bom.xlsx", "جوال 3", new String[]{"7000000000004"}, new int[]{2}, c);
        assertEquals(0, a[0].sumValue.compareTo(new BigDecimal("538")));         // 510 + 28

        List<Repository.MergeInput> in = new ArrayList<>();
        in.add(Workflows.readForMerge(fa, "جوال 1.xlsx", in));
        in.add(Workflows.readForMerge(fb, "جوال 2.xlsx", in));
        in.add(Workflows.readForMerge(fc, "جوال 3.xlsx", in));
        try { Workflows.readForMerge(fa, "نسخة.xlsx", in); fail("same file twice must be refused"); }
        catch (java.io.IOException e) { assertTrue(e.getMessage().contains("لن يُدمج مرتين")); }

        long sid = Workflows.createMerged(ctx, "جرد مجمّع", "المحل", "2026-11-25", "ر.ي", in, null);
        Models.Session s = repo.session(sid);
        assertTrue(s.isMerged());
        Models.Stats m = repo.stats(sid);
        assertEquals(9 + 20 + 9, m.items);
        BigDecimal expected = a[0].sumValue.add(b[0].sumValue).add(c[0].sumValue);
        assertEquals("grand total = sum of the phones", 0, m.sumValue.compareTo(expected));
        assertEquals(0, m.sumQty.compareTo(a[0].sumQty.add(b[0].sumQty).add(c[0].sumQty)));
        List<Models.Part> parts = repo.parts(sid);
        assertEquals(3, parts.size());
        assertEquals(0, parts.get(0).value.compareTo(a[0].sumValue));
        assertEquals(0, parts.get(1).value.compareTo(b[0].sumValue));
        assertEquals(0, parts.get(2).value.compareTo(c[0].sumValue));
        // f10 and f_bom contain the same barcodes -> reported, not merged
        assertTrue(repo.crossFileDuplicateBarcodes(sid) > 0);
        // items keep file order: first file's first row is first
        assertEquals("عدسات فريش ليدي", repo.query(sid, null, null, null, Models.Sort.SEQ, 1, 0).get(0).name);
        // the merged report never becomes the active counting session
        assertNotEquals(sid, Settings.activeSession(ctx));

        // print: list pages + files page + final page
        String dir = System.getProperty("smartstock.out", "");
        File png = dir.isEmpty() ? null : new File(dir, "print_pages_merged");
        if (png != null) png.mkdirs();
        WorkflowTest.BitmapSink sink = new WorkflowTest.BitmapSink(png, 2f, 999);
        Typeface reg = Typeface.createFromFile(new File("src/main/res/font/noto_arabic.ttf"));
        Typeface bold = Typeface.createFromFile(new File("src/main/res/font/noto_arabic_bold.ttf"));
        ReportPdf.Options o = new ReportPdf.Options();
        o.currency = "ر.ي";
        ReportPdf.Result r = new ReportPdf(reg, bold).write(repo, sid, o, new File(ctx.getCacheDir(), "m.pdf"), null, sink);
        assertEquals(38, r.rows);
        assertEquals(r.pages, sink.pages);
        assertTrue(r.pages >= 4);
        assertEquals(0, r.sumValue.compareTo(expected));
        System.out.println("MERGED: 3 files, " + m.items + " items, total " + Num.money(m.sumValue) + ", " + r.pages + " pages");
    }

    @Test public void mergeScreenEndToEnd() throws Exception {
        Models.Stats[] a = new Models.Stats[1], b = new Models.Stats[1];
        File fa = phone("f10_multisheet.xlsx", "phone1", new String[]{"4600"}, new int[]{20}, a);
        File fb = phone("f_single_reordered.xlsx", "phone2", new String[]{"8000000000001"}, new int[]{4}, b);
        MergeActivity act = Robolectric.buildActivity(MergeActivity.class).setup().get();
        java.lang.reflect.Method add = MergeActivity.class.getDeclaredMethod("add", List.class);
        add.setAccessible(true);
        add.invoke(act, Arrays.asList(Uri.fromFile(fa), Uri.fromFile(fb), Uri.fromFile(fa)));
        flush();
        java.lang.reflect.Field f = MergeActivity.class.getDeclaredField("inputs");
        f.setAccessible(true);
        assertEquals("duplicate file skipped", 2, ((List<?>) f.get(act)).size());
        org.robolectric.shadows.ShadowDialog.getLatestDialog().dismiss();       // the "skipped file" message
        java.lang.reflect.Method merge = MergeActivity.class.getDeclaredMethod("merge");
        merge.setAccessible(true);
        merge.invoke(act);
        flush();
        android.content.Intent next = shadowOf(act).getNextStartedActivity();
        assertEquals(PrintActivity.class.getName(), next.getComponent().getClassName());
        long sid = next.getLongExtra(PrintActivity.EXTRA_SESSION, -1);
        assertEquals(0, repo.stats(sid).sumValue.compareTo(a[0].sumValue.add(b[0].sumValue)));
        PrintActivity pr = Robolectric.buildActivity(PrintActivity.class, next).setup().get();
        flush();
        com.smartstock.ui.UiFlowShots.shot(pr, "13_print_merged");
    }

    static void flush() throws Exception {
        for (int i = 0; i < 6; i++) {
            com.smartstock.ui.UiFlowShots.drain();
            shadowOf(Looper.getMainLooper()).idle();
        }
    }

    /** A v1 database (app 1.0.x) is upgraded in place to v2 without losing sessions or counts. */
    @Test public void migrationFromV1KeepsData() throws Exception {
        Db.reset();
        ctx.deleteDatabase(Db.NAME);
        File path = ctx.getDatabasePath(Db.NAME);
        path.getParentFile().mkdirs();
        SQLiteDatabase v1 = SQLiteDatabase.openOrCreateDatabase(path, null);
        Db.createV1(v1);
        ContentValues s = new ContentValues();
        s.put("name", "قديمة"); s.put("count_date", "2026-11-01"); s.put("created_at", 1L); s.put("file_name", "a.xlsx");
        s.put("source_file", "sources/a.xlsx"); s.put("sheet_name", "x"); s.put("sheet_path", "x"); s.put("header_row", 1);
        s.put("col_map", "NAME=1;BARCODE=4;QTY=5;COST=6"); s.put("headers", "[]"); s.put("total_col", 7); s.put("total_created", 1); s.put("item_count", 1);
        long sid = v1.insert("sessions", null, s);
        ContentValues it = new ContentValues();
        it.put("session_id", sid); it.put("seq", 0); it.put("row_num", 2); it.put("name", "صنف"); it.put("name_norm", "صنف");
        it.put("barcode", "1"); it.put("cost", "2.5"); it.put("qty", "4"); it.put("counted", 1);
        v1.insert("items", null, it);
        v1.setVersion(1);
        v1.close();

        repo = new Repository(Db.get(ctx));          // triggers onUpgrade(1 -> 2)
        Models.Session old = repo.session(sid);
        assertEquals("قديمة", old.name);
        assertEquals("COUNT", old.kind);
        assertFalse(old.isMerged());
        assertEquals(0, repo.stats(sid).sumValue.compareTo(new BigDecimal(10)));
        try (Cursor c = Db.get(ctx).getReadableDatabase().rawQuery("PRAGMA user_version", null)) { c.moveToFirst(); assertEquals(Db.VERSION, c.getInt(0)); }
    }
}
