package com.smartstock.data;
import com.smartstock.core.*;
import org.junit.Test; import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner; import org.robolectric.annotation.Config;
import static org.junit.Assert.*;
/** Same check with the Android platform XML parser (android.util.Xml), which is what runs on the phone. */
@RunWith(RobolectricTestRunner.class) @Config(sdk = 34)
public class BomAndroidTest {
    @Test public void bomInXmlPartsAndroidParser() throws Exception {
        try (XlsxPackage pkg = new XlsxPackage(TestUtil.fixture("f_bom.xlsx"), Workflows.PARSER)) {
            XlsxImporter.HeaderScan h = XlsxImporter.scanHeader(pkg, pkg.defaultSheet());
            XlsxImporter.Result r = XlsxImporter.read(pkg, pkg.defaultSheet(), h.headerRow, h.match.map, h.headers, null);
            assertEquals(9, r.rows.size());
            assertEquals("0012345", r.rows.get(1).barcode);
        }
    }
}
