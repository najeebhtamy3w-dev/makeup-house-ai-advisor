package com.smartstock.data;

import android.content.Context;
import android.graphics.Typeface;

import androidx.test.core.app.ApplicationProvider;

import com.smartstock.core.Field;
import com.smartstock.core.Num;
import com.smartstock.core.TestUtil;
import com.smartstock.core.XlsxImporter;
import com.smartstock.core.XlsxPackage;
import com.smartstock.pdf.ReportPdf;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class WorkflowTest {
    Context ctx;
    Repository repo;

    @Before public void setUp() {
        ctx = ApplicationProvider.getApplicationContext();
        Db.reset();
        ctx.deleteDatabase(Db.NAME);
        repo = new Repository(Db.get(ctx));
    }

    @After public void tearDown() { Db.reset(); }

    static String tok() { return UUID.randomUUID().toString(); }

    long importFixture(String name, boolean decimals) throws Exception {
        File staged = TestUtil.fixture(name);
        XlsxImporter.Result r;
        try (XlsxPackage pkg = new XlsxPackage(staged, Workflows.PARSER)) {
            XlsxPackage.SheetRef s = pkg.defaultSheet();
            XlsxImporter.HeaderScan h = XlsxImporter.scanHeader(pkg, s);
            r = XlsxImporter.read(pkg, s, h.headerRow, h.match.map, h.headers, null);
        }
        Repository.SessionDraft d = new Repository.SessionDraft();
        d.name = "جلسة " + name; d.shop = "محل التجربة"; d.countDate = "2026-11-25"; d.fileName = name; d.allowDecimal = decimals;
        return Workflows.createSession(ctx, staged, r, d, null);
    }

    Models.Item byBarcode(long sid, String b) { List<Models.Item> l = repo.findByBarcode(sid, b); assertEquals(1, l.size()); return l.get(0); }

    // ---------------------------------------------------------------- B. counting

    @Test public void cumulativeCountingMandatoryExample() throws Exception {
        long sid = importFixture("f10_multisheet.xlsx", false);
        Models.Item it = byBarcode(sid, "4600");
        assertFalse(it.counted);
        assertEquals(Models.SaveResult.Kind.OK, repo.addCount(it.id, new BigDecimal(12), tok()).kind);
        Models.SaveResult r = repo.addCount(it.id, new BigDecimal(8), tok());
        assertEquals(Models.SaveResult.Kind.OK, r.kind);
        assertEquals(0, r.item.qty.compareTo(new BigDecimal(20)));
        assertEquals("510.00", Num.money(r.item.total()));
        Models.Item b = byBarcode(sid, "0012345");
        repo.addCount(b.id, new BigDecimal(100), tok());
        assertEquals("28.00", Num.money(repo.item(b.id).total()));
        Models.Stats st = repo.stats(sid);
        assertEquals(2, st.counted);
        assertEquals(0, st.sumQty.compareTo(new BigDecimal(120)));
        assertEquals(0, st.sumValue.compareTo(new BigDecimal("538")));
    }

    @Test public void doubleSaveIsBlocked() throws Exception {
        long sid = importFixture("f10_multisheet.xlsx", false);
        Models.Item it = byBarcode(sid, "4600");
        String t = tok();
        assertEquals(Models.SaveResult.Kind.OK, repo.addCount(it.id, new BigDecimal(5), t).kind);
        assertEquals(Models.SaveResult.Kind.DUPLICATE, repo.addCount(it.id, new BigDecimal(5), t).kind);
        assertEquals(0, repo.item(it.id).qty.compareTo(new BigDecimal(5)));
        assertEquals(1, repo.opCount(sid));
    }

    @Test public void invalidQuantitiesRejected() throws Exception {
        long sid = importFixture("f10_multisheet.xlsx", false);
        Models.Item it = byBarcode(sid, "4600");
        assertEquals(Models.SaveResult.Kind.INVALID, repo.addCount(it.id, new BigDecimal(-1), tok()).kind);
        assertEquals(Models.SaveResult.Kind.INVALID, repo.addCount(it.id, new BigDecimal("1.5"), tok()).kind); // session without decimals
        assertFalse(repo.item(it.id).counted);
        long sid2 = importFixture("f10_multisheet.xlsx", true);
        Models.Item it2 = byBarcode(sid2, "4600");
        assertEquals(Models.SaveResult.Kind.OK, repo.addCount(it2.id, new BigDecimal("1.5"), tok()).kind);
    }

    @Test public void zeroCountIsDistinctFromNotCounted() throws Exception {
        long sid = importFixture("f10_multisheet.xlsx", false);
        Models.Item it = byBarcode(sid, "7000000000002");
        assertEquals(0, it.state());
        repo.addCount(it.id, BigDecimal.ZERO, tok());
        Models.Item after = repo.item(it.id);
        assertTrue(after.counted);
        assertEquals(1, after.state());
        Models.Stats st = repo.stats(sid);
        assertEquals(1, st.counted);
        assertEquals(1, st.countedZero);
        assertEquals(0, st.positive);
        assertEquals(1, repo.count(sid, null, Models.Filter.ZERO, null));
        assertEquals(8, repo.count(sid, null, Models.Filter.UNCOUNTED, null));
    }

    @Test public void correctionAndUndoKeepFullHistory() throws Exception {
        long sid = importFixture("f10_multisheet.xlsx", false);
        Models.Item it = byBarcode(sid, "4600");
        repo.addCount(it.id, new BigDecimal(12), tok());
        repo.addCount(it.id, new BigDecimal(8), tok());
        Models.SaveResult c = repo.correct(it.id, new BigDecimal(18), "خطأ عد", tok());
        assertEquals(Models.SaveResult.Kind.OK, c.kind);
        assertEquals(0, c.item.qty.compareTo(new BigDecimal(18)));
        assertEquals("CORRECT", c.op.type);
        assertEquals("خطأ عد", c.op.reason);
        // undo last (the correction) -> back to 20
        Models.Op last = repo.lastUndoable(sid);
        assertEquals(c.op.id, last.id);
        Models.SaveResult u = repo.undo(last.id, tok());
        assertEquals(Models.SaveResult.Kind.OK, u.kind);
        assertEquals(0, repo.item(it.id).qty.compareTo(new BigDecimal(20)));
        assertEquals(Long.valueOf(c.op.id), u.op.refOpId);
        // undo twice more -> back to not counted
        repo.undo(repo.lastUndoable(sid).id, tok());
        repo.undo(repo.lastUndoable(sid).id, tok());
        Models.Item back = repo.item(it.id);
        assertEquals(0, back.qty.signum());
        assertFalse(back.counted);
        assertNull(repo.lastUndoable(sid));
        assertEquals(6, repo.opCount(sid)); // nothing deleted: 3 ops + 3 undo records
        assertEquals(0, repo.verifyLog(sid));
    }

    @Test public void duplicateBarcodeReturnsAllRowsAndLeadingZeroFallback() throws Exception {
        long sid = importFixture("f10_multisheet.xlsx", false);
        List<Models.Item> dup = repo.findByBarcode(sid, "6281000000011");
        assertEquals(2, dup.size());
        assertNotEquals(dup.get(0).id, dup.get(1).id);
        assertNotEquals(dup.get(0).rowNum, dup.get(1).rowNum);
        assertEquals(1, repo.findByBarcode(sid, "12345").size());       // scanner dropped zeros
        assertEquals(1, repo.findByBarcode(sid, "00004600").size());    // scanner added zeros
        assertEquals(0, repo.findByBarcode(sid, "999").size());
        assertEquals(1, repo.findByBarcode(sid, "٤٦٠٠").size());        // Arabic-Indic digits
    }

    @Test public void searchByNameAndFilters() throws Exception {
        long sid = importFixture("f10_multisheet.xlsx", false);
        assertEquals(2, repo.count(sid, "احمر شفاه", null, null));          // alef normalization
        assertEquals(1, repo.count(sid, "بدون باركود", null, null));
        assertEquals(3, repo.count(sid, null, null, "عطور"));
        List<Models.Item> byCost = repo.query(sid, null, Models.Filter.ALL, null, Models.Sort.COST, 3, 0);
        assertEquals("عطر كبير", byCost.get(0).name);
        assertEquals(9, repo.query(sid, null, null, null, Models.Sort.NAME, 100, 0).size());
        assertEquals(java.util.Arrays.asList("عدسات", "مكياج", "عناية", "عطور"), repo.groups(sid));
    }

    @Test public void sessionsAreIsolatedAndSurviveReopen() throws Exception {
        long a = importFixture("f10_multisheet.xlsx", false);
        long b = importFixture("f10_multisheet.xlsx", false);
        repo.addCount(byBarcode(a, "4600").id, new BigDecimal(7), tok());
        assertEquals(1, repo.stats(a).counted);
        assertEquals(0, repo.stats(b).counted);
        // simulate process death: close and reopen database
        Db.reset();
        repo = new Repository(Db.get(ctx));
        assertEquals(0, byBarcode(a, "4600").qty.compareTo(new BigDecimal(7)));
        assertEquals(2, repo.sessions().size());
        repo.deleteSession(b);
        assertNull(repo.session(b));
        assertEquals(1, repo.stats(a).counted);
    }

    // ---------------------------------------------------------------- D. export

    @Test public void verifiedExportMatchesDatabase() throws Exception {
        long sid = importFixture("f10_multisheet.xlsx", false);
        repo.addCount(byBarcode(sid, "4600").id, new BigDecimal(12), tok());
        repo.addCount(byBarcode(sid, "4600").id, new BigDecimal(8), tok());
        repo.addCount(byBarcode(sid, "0012345").id, new BigDecimal(100), tok());
        Models.Session s = repo.session(sid);
        File src = new File(ctx.getFilesDir(), s.sourceFile);
        byte[] before = java.nio.file.Files.readAllBytes(src.toPath());
        Workflows.ExportReport rep = Workflows.exportVerified(ctx, sid);
        assertEquals(9, rep.rows);
        assertEquals(0, rep.sumValue.compareTo(new BigDecimal(538)));
        assertArrayEquals(before, java.nio.file.Files.readAllBytes(src.toPath()));
        // re-import the exported file: quantities present, total column created
        try (XlsxPackage pkg = new XlsxPackage(rep.file, Workflows.PARSER)) {
            XlsxImporter.HeaderScan h = XlsxImporter.scanHeader(pkg, pkg.defaultSheet());
            assertEquals(Integer.valueOf(10), h.match.map.get(Field.TOTAL));
            XlsxImporter.Result r = XlsxImporter.read(pkg, pkg.defaultSheet(), h.headerRow, h.match.map, h.headers, null);
            assertEquals(0, r.rows.get(0).fileQty.compareTo(new BigDecimal(20)));
        }
        String out = System.getProperty("smartstock.out", "");
        if (!out.isEmpty()) {
            Backup.copyFile(TestUtil.fixture("f10_multisheet.xlsx"), new File(out, "SMART_STOCK_SAMPLE_INPUT.xlsx"));
            Backup.copyFile(rep.file, new File(out, "SMART_STOCK_SAMPLE_OUTPUT.xlsx"));
        }
    }

    // ---------------------------------------------------------------- F. backup / restore

    @Test public void backupAndRealRestore() throws Exception {
        long sid = importFixture("f10_multisheet.xlsx", false);
        repo.addCount(byBarcode(sid, "4600").id, new BigDecimal(12), tok());
        repo.addCount(byBarcode(sid, "7000000000004").id, new BigDecimal(3), tok());
        repo.addCount(byBarcode(sid, "7000000000002").id, BigDecimal.ZERO, tok());
        Models.Stats before = repo.stats(sid);
        int opsBefore = repo.opCount(sid);
        File bk = new File(ctx.getCacheDir(), "bk.zip");
        try (FileOutputStream o = new FileOutputStream(bk)) { Backup.create(ctx, o, "test"); }
        // change data after the backup
        repo.addCount(byBarcode(sid, "4600").id, new BigDecimal(1000), tok());
        long other = importFixture("f_single_reordered.xlsx", false);
        assertNotNull(repo.session(other));
        // validate + apply
        Backup.Plan plan = Backup.validate(ctx, bk);
        assertEquals(1, plan.sessions.size());
        Backup.apply(ctx, plan, "test");
        repo = new Repository(Db.get(ctx));
        Models.Stats after = repo.stats(sid);
        assertEquals(before.counted, after.counted);
        assertEquals(before.countedZero, after.countedZero);
        assertEquals(0, before.sumQty.compareTo(after.sumQty));
        assertEquals(0, before.sumValue.compareTo(after.sumValue));
        assertEquals(opsBefore, repo.opCount(sid));
        assertNull(repo.session(other));
        assertEquals(0, byBarcode(sid, "4600").qty.compareTo(new BigDecimal(12)));
        // export still works after restore (source workbook restored too)
        assertEquals(9, Workflows.exportVerified(ctx, sid).rows);
        assertTrue(new File(ctx.getFilesDir(), "pre_restore_backup.zip").exists());
    }

    @Test public void corruptedBackupIsRejected() throws Exception {
        long sid = importFixture("f10_multisheet.xlsx", false);
        repo.addCount(byBarcode(sid, "4600").id, new BigDecimal(12), tok());
        File bk = new File(ctx.getCacheDir(), "bk.zip");
        try (FileOutputStream o = new FileOutputStream(bk)) { Backup.create(ctx, o, "test"); }
        // tamper with one entry (rewrite zip with modified settings.json)
        File bad = new File(ctx.getCacheDir(), "bad.zip");
        try (java.util.zip.ZipFile z = new java.util.zip.ZipFile(bk);
             java.util.zip.ZipOutputStream zo = new java.util.zip.ZipOutputStream(new FileOutputStream(bad))) {
            for (java.util.Enumeration<? extends java.util.zip.ZipEntry> en = z.entries(); en.hasMoreElements(); ) {
                java.util.zip.ZipEntry e = en.nextElement();
                zo.putNextEntry(new java.util.zip.ZipEntry(e.getName()));
                byte[] b = z.getInputStream(e).readAllBytes();
                if (e.getName().equals("settings.json")) b = "{\"x\":{\"t\":\"s\",\"v\":\"tampered\"}}".getBytes();
                zo.write(b);
                zo.closeEntry();
            }
        }
        try { Backup.validate(ctx, bad); fail("tampered backup accepted"); }
        catch (java.io.IOException e) { assertTrue(e.getMessage(), e.getMessage().contains("بصمة")); }
        assertEquals(1, repo.stats(sid).counted); // live data untouched
    }

    // ---------------------------------------------------------------- 10k/50k sessions

    @Test public void largeSession50k() throws Exception {
        File f = TestUtil.bigWorkbook(50000, false);
        long t0 = System.currentTimeMillis();
        XlsxImporter.Result r;
        try (XlsxPackage pkg = new XlsxPackage(f, Workflows.PARSER)) {
            XlsxImporter.HeaderScan h = XlsxImporter.scanHeader(pkg, pkg.defaultSheet());
            r = XlsxImporter.read(pkg, pkg.defaultSheet(), h.headerRow, h.match.map, h.headers, null);
        }
        Repository.SessionDraft d = new Repository.SessionDraft();
        d.name = "50k"; d.countDate = "2026-11-25"; d.fileName = "big.xlsx";
        long sid = Workflows.createSession(ctx, f, r, d, null);
        long t1 = System.currentTimeMillis();
        BigDecimal expected = BigDecimal.ZERO;
        for (int i = 1; i <= 50000; i += 50) {
            Models.Item it = byBarcode(sid, String.format("62%011d", i));
            repo.addCount(it.id, new BigDecimal(i % 9 + 1), tok());
            expected = expected.add(TestUtil.cost(i).multiply(new BigDecimal(i % 9 + 1)));
        }
        long t2 = System.currentTimeMillis();
        Models.Stats st = repo.stats(sid);
        long t3 = System.currentTimeMillis();
        assertEquals(50000, st.items);
        assertEquals(1000, st.counted);
        assertEquals(0, st.sumValue.compareTo(expected));
        assertTrue(repo.count(sid, "صنف تجريبي رقم 4999", null, null) >= 11); // names 4999, 49990..49999 (+ barcodes containing 4999)
        Workflows.ExportReport rep = Workflows.exportVerified(ctx, sid);
        long t4 = System.currentTimeMillis();
        assertEquals(50000, rep.rows);
        assertEquals(0, rep.sumValue.compareTo(expected));
        System.out.println("50K: import+session " + (t1 - t0) + "ms, 1000 saves " + (t2 - t1) + "ms, stats " + (t3 - t2) + "ms, export+verify " + (t4 - t3) + "ms");
    }

    // ---------------------------------------------------------------- E. PDF

    /** Renders pages with the real drawing code onto bitmaps (PdfDocument has no native impl in Robolectric). */
    static final class BitmapSink implements ReportPdf.PageSink {
        final File dir; final float scale; final int saveFirst; int pages; android.graphics.Bitmap bmp; int current;
        final java.util.List<Integer> saved = new java.util.ArrayList<>();
        BitmapSink(File dir, float scale, int saveFirst) { this.dir = dir; this.scale = scale; this.saveFirst = saveFirst; }
        @Override public android.graphics.Canvas begin(int n, int w, int h) {
            current = n;
            bmp = android.graphics.Bitmap.createBitmap(Math.round(w * scale), Math.round(h * scale), android.graphics.Bitmap.Config.ARGB_8888);
            android.graphics.Canvas c = new android.graphics.Canvas(bmp);
            c.drawColor(android.graphics.Color.WHITE);
            c.scale(scale, scale);
            return c;
        }
        @Override public void end() {
            pages++;
            if (dir != null && (current <= saveFirst)) save(current);
            lastBmp = bmp;
        }
        android.graphics.Bitmap lastBmp;
        void save(int n) {
            try (FileOutputStream o = new FileOutputStream(new File(dir, String.format(java.util.Locale.US, "page_%04d.png", n)))) {
                bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, o);
                saved.add(n);
            } catch (Exception e) { throw new RuntimeException(e); }
        }
        @Override public void writeTo(File out) {
            // keep the final report page as well
            if (dir != null && !saved.contains(current)) save(current);
        }
        @Override public void close() {}
    }

    Typeface font(boolean bold) {
        File f = new File("src/main/res/font/" + (bold ? "noto_arabic_bold.ttf" : "noto_arabic.ttf"));
        return Typeface.createFromFile(f);
    }

    @Test public void pdfReportAllItemsWithFinalPage() throws Exception {
        long sid = importFixture("f10_multisheet.xlsx", false);
        repo.addCount(byBarcode(sid, "4600").id, new BigDecimal(12), tok());
        repo.addCount(byBarcode(sid, "4600").id, new BigDecimal(8), tok());
        repo.addCount(byBarcode(sid, "0012345").id, new BigDecimal(100), tok());
        repo.addCount(byBarcode(sid, "7000000000002").id, BigDecimal.ZERO, tok());
        ReportPdf.Options o = new ReportPdf.Options();
        o.currency = "ر.ي";
        File out = new File(ctx.getCacheDir(), "r.pdf");
        String dir = System.getProperty("smartstock.out", "");
        File pngDir = dir.isEmpty() ? null : new File(dir, "print_pages_small");
        if (pngDir != null) pngDir.mkdirs();
        BitmapSink sink = new BitmapSink(pngDir, 2f, 999);
        ReportPdf.Result res = new ReportPdf(font(false), font(true)).write(repo, sid, o, out, null, sink);
        assertEquals(9, res.rows);
        assertEquals(2, res.pages);       // 1 list page + 1 final report page
        assertEquals(2, sink.pages);
        assertEquals(0, res.sumValue.compareTo(new BigDecimal(538)));
        // the page is not blank: the table and text were drawn
        android.graphics.Bitmap b = sink.lastBmp;
        int dark = 0;
        for (int x = 0; x < b.getWidth(); x += 4) for (int y = 0; y < b.getHeight(); y += 4) if ((b.getPixel(x, y) & 0xFF) < 128) dark++;
        assertTrue("summary page has content: " + dark, dark > 500);
    }

    @Test public void pdfLargeReportPaginatesWithoutCrash() throws Exception {
        File f = TestUtil.bigWorkbook(10000, false);
        XlsxImporter.Result r;
        try (XlsxPackage pkg = new XlsxPackage(f, Workflows.PARSER)) {
            XlsxImporter.HeaderScan h = XlsxImporter.scanHeader(pkg, pkg.defaultSheet());
            r = XlsxImporter.read(pkg, pkg.defaultSheet(), h.headerRow, h.match.map, h.headers, null);
        }
        Repository.SessionDraft d = new Repository.SessionDraft();
        d.name = "10k"; d.countDate = "2026-11-25"; d.fileName = "big.xlsx";
        long sid = Workflows.createSession(ctx, f, r, d, null);
        long t0 = System.currentTimeMillis();
        File out = new File(ctx.getCacheDir(), "big.pdf");
        String dir = System.getProperty("smartstock.out", "");
        File pngDir = dir.isEmpty() ? null : new File(dir, "print_pages_10k");
        if (pngDir != null) pngDir.mkdirs();
        BitmapSink sink = new BitmapSink(pngDir, pngDir == null ? 0.25f : 2f, 3);
        ReportPdf.Result res = new ReportPdf(font(false), font(true)).write(repo, sid, new ReportPdf.Options(), out, null, sink);
        System.out.println("PDF 10000 rows: " + res.pages + " pages, " + (System.currentTimeMillis() - t0) + " ms");
        assertEquals(res.pages, sink.pages);
        assertEquals(10000, res.rows);
        assertTrue(res.pages > 300);
        // filtered scope prints a separate scope total
        ReportPdf.Options o = new ReportPdf.Options();
        o.scope = ReportPdf.Scope.GROUP; o.group = "مجموعة 3";
        ReportPdf.Result g = new ReportPdf(font(false), font(true)).write(repo, sid, o, new File(ctx.getCacheDir(), "g.pdf"), null, new BitmapSink(null, 0.25f, 0));
        assertEquals(250, g.rows);
    }
}
