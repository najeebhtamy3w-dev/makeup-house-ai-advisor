package com.smartstock.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Local SQLite database. Schema changes MUST be added as a new step in onUpgrade() (never drop
 * user data). Quantities, costs and totals are stored as exact decimal TEXT (BigDecimal plain string).
 */
public final class Db extends SQLiteOpenHelper {
    public static final String NAME = "smartstock.db";
    public static final int VERSION = 2;

    private static Db instance;

    public static synchronized Db get(Context c) {
        if (instance == null) instance = new Db(c.getApplicationContext());
        return instance;
    }

    /** Used by restore: closes and forgets the singleton so the next get() reopens the new file. */
    public static synchronized void reset() {
        if (instance != null) { instance.close(); instance = null; }
    }

    private Db(Context c) { super(c, NAME, null, VERSION); }

    @Override public void onConfigure(SQLiteDatabase db) {
        db.setForeignKeyConstraintsEnabled(true);
        // Rollback-journal mode: every commit is fully in the main file (durable, and safe to copy for backup).
        db.disableWriteAheadLogging();
    }

    @Override public void onCreate(SQLiteDatabase db) {
        createV1(db);
        onUpgrade(db, 1, VERSION);
    }

    static void createV1(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE sessions (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "shop TEXT NOT NULL DEFAULT ''," +
                "count_date TEXT NOT NULL," +          // yyyy-MM-dd chosen by user
                "created_at INTEGER NOT NULL," +
                "finished_at INTEGER," +
                "status TEXT NOT NULL DEFAULT 'ACTIVE'," + // ACTIVE | FINISHED
                "file_name TEXT NOT NULL," +
                "source_file TEXT NOT NULL," +         // internal copy (relative to files dir)
                "sheet_name TEXT NOT NULL," +
                "sheet_path TEXT NOT NULL," +
                "header_row INTEGER NOT NULL," +
                "col_map TEXT NOT NULL," +
                "headers TEXT NOT NULL," +              // JSON array of original header texts
                "total_col INTEGER NOT NULL," +
                "total_created INTEGER NOT NULL," +
                "allow_decimal INTEGER NOT NULL DEFAULT 0," +
                "currency TEXT NOT NULL DEFAULT ''," +
                "item_count INTEGER NOT NULL," +
                "import_summary TEXT NOT NULL DEFAULT ''," +
                "last_export TEXT)");
        db.execSQL("CREATE TABLE items (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE," +
                "seq INTEGER NOT NULL," +               // original order in the sheet
                "row_num INTEGER NOT NULL," +           // Excel row number (link to source row)
                "grp TEXT NOT NULL DEFAULT ''," +
                "name TEXT NOT NULL," +
                "unit TEXT NOT NULL DEFAULT ''," +
                "pack TEXT NOT NULL DEFAULT ''," +
                "barcode TEXT NOT NULL DEFAULT ''," +
                "barcode_key TEXT NOT NULL DEFAULT ''," + // barcode without leading zeros (fallback lookup)
                "name_norm TEXT NOT NULL," +
                "cost TEXT," +                           // NULL = invalid/unknown cost (never silently zero)
                "cost_issue TEXT," +
                "qty TEXT NOT NULL DEFAULT '0'," +
                "counted INTEGER NOT NULL DEFAULT 0," +  // 0 = not counted, 1 = counted (qty may be 0)
                "updated_at INTEGER)");
        db.execSQL("CREATE INDEX ix_items_session_seq ON items(session_id, seq)");
        db.execSQL("CREATE INDEX ix_items_session_barcode ON items(session_id, barcode)");
        db.execSQL("CREATE INDEX ix_items_session_bkey ON items(session_id, barcode_key)");
        db.execSQL("CREATE INDEX ix_items_session_name ON items(session_id, name_norm)");
        db.execSQL("CREATE INDEX ix_items_session_grp ON items(session_id, grp)");
        db.execSQL("CREATE TABLE ops (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE," +
                "item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE," +
                "barcode TEXT NOT NULL DEFAULT ''," +
                "ts INTEGER NOT NULL," +
                "type TEXT NOT NULL," +                 // ADD | CORRECT | UNDO
                "prev_qty TEXT NOT NULL," +
                "input_qty TEXT NOT NULL," +
                "new_qty TEXT NOT NULL," +
                "prev_counted INTEGER NOT NULL," +
                "reason TEXT," +
                "ref_op_id INTEGER," +                  // for UNDO: the reversed operation
                "undone INTEGER NOT NULL DEFAULT 0," +
                "token TEXT NOT NULL UNIQUE)");          // idempotency key: blocks double saves
        db.execSQL("CREATE INDEX ix_ops_session ON ops(session_id, id)");
        db.execSQL("CREATE INDEX ix_ops_item ON ops(item_id, id)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Incremental, data-preserving migrations. Never drop user data.
        if (oldVersion < 2) {
            // v2 (app 1.1.0): merged multi-phone reports
            db.execSQL("ALTER TABLE sessions ADD COLUMN kind TEXT NOT NULL DEFAULT 'COUNT'"); // COUNT | MERGED
            db.execSQL("ALTER TABLE sessions ADD COLUMN parts TEXT NOT NULL DEFAULT ''");     // JSON: merged source files
            db.execSQL("ALTER TABLE items ADD COLUMN src TEXT NOT NULL DEFAULT ''");          // source file label (merged)
        }
    }

    @Override public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Never wipe user data on downgrade; refuse instead.
        throw new IllegalStateException("لا يمكن فتح قاعدة بيانات من إصدار أحدث للتطبيق (" + oldVersion + ")");
    }
}
