package com.smartstock.data;

import com.smartstock.core.ColumnMap;
import com.smartstock.core.Num;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/** Plain data holders. */
public final class Models {
    private Models() {}

    public static final class Session {
        public long id;
        public String name, shop, countDate, status, fileName, sourceFile, sheetName, sheetPath, currency, importSummary, lastExport;
        public long createdAt; public Long finishedAt;
        public int headerRow, totalCol, itemCount;
        public boolean totalCreated, allowDecimal;
        public ColumnMap colMap;
        public List<String> headers = new ArrayList<>();
        public String kind = "COUNT", parts = "";
        public boolean isFinished() { return "FINISHED".equals(status); }
        /** A read-only report merged from several phones' exported files. */
        public boolean isMerged() { return "MERGED".equals(kind); }
    }

    public static final class Item {
        public long id, sessionId;
        public int seq, rowNum;
        public String group, name, unit, pack, barcode, costIssue;
        public BigDecimal cost;   // null => unknown
        public BigDecimal qty;
        public boolean counted;
        public Long updatedAt;
        public BigDecimal total() { return Num.total(qty, cost); }
        public int state() { return !counted ? 0 : (qty.signum() == 0 ? 1 : 2); } // 0 not counted, 1 counted zero, 2 positive
    }

    public static final class Op {
        public long id, sessionId, itemId, ts;
        public Long refOpId;
        public String barcode, type, reason, itemName;
        public BigDecimal prevQty, inputQty, newQty;
        public boolean prevCounted, undone;
    }

    public static final class Stats {
        public int items, counted, uncounted, countedZero, positive, invalidCost, valuedMissing;
        public BigDecimal sumQty = BigDecimal.ZERO, sumValue = BigDecimal.ZERO;
        public String percent() { return Num.percent(counted, items); }
    }

    /** One source file inside a merged report. */
    public static final class Part {
        public String label, fileName, sha256;
        public int items, positive;
        public BigDecimal qty = BigDecimal.ZERO, value = BigDecimal.ZERO;
    }

    public static final class GroupStat {
        public String group; public int items, counted; public BigDecimal qty = BigDecimal.ZERO, value = BigDecimal.ZERO;
    }

    public enum Filter { ALL, COUNTED, UNCOUNTED, ZERO, POSITIVE }
    public enum Sort { SEQ, NAME, QTY, COST, TOTAL }

    public static final class SaveResult {
        public enum Kind { OK, DUPLICATE, INVALID, NOT_FOUND, NOTHING }
        public Kind kind; public String message; public Item item; public Op op;
        static SaveResult of(Kind k, String m) { SaveResult r = new SaveResult(); r.kind = k; r.message = m; return r; }
    }
}
