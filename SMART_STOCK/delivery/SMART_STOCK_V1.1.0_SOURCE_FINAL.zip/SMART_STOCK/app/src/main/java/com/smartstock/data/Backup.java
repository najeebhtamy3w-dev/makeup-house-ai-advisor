package com.smartstock.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.smartstock.core.Num;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * Full local backup: database (sessions, items, quantities, counting states, operation log),
 * the stored source workbooks needed for export, and settings. Every entry carries a SHA-256
 * in manifest.json, and per-session totals are stored so a restore can be verified end-to-end.
 */
public final class Backup {
    private Backup() {}

    public static final String FORMAT = "SMARTSTOCK-BACKUP-1";

    public static final class SessionCheck {
        public long id; public String name; public int items, counted, ops; public String sumQty, sumValue;
    }

    public static final class Plan {
        public File dir;                 // validated extracted content
        public String createdAt, appVersion;
        public int dbVersion;
        public final List<SessionCheck> sessions = new ArrayList<>();
    }

    // ------------------------------------------------------------------ create

    public static void create(Context ctx, OutputStream out, String appVersion) throws Exception {
        Db db = Db.get(ctx);
        SQLiteDatabase sdb = db.getWritableDatabase();
        Repository repo = new Repository(db);
        File dbFile = ctx.getDatabasePath(Db.NAME);
        File tmpDb = new File(ctx.getCacheDir(), "backup_snapshot.db");
        // consistent snapshot: copy while holding an exclusive transaction (all writes go through the same thread anyway)
        sdb.beginTransactionNonExclusive();
        try { copyFile(dbFile, tmpDb); } finally { sdb.endTransaction(); }

        JSONObject man = new JSONObject();
        man.put("format", FORMAT);
        man.put("createdAt", new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(new java.util.Date()));
        man.put("appVersion", appVersion);
        man.put("dbVersion", Db.VERSION);
        JSONArray sess = new JSONArray();
        for (Models.Session s : repo.sessions()) sess.put(check(repo, s));
        man.put("sessions", sess);
        JSONObject sums = new JSONObject();

        try (ZipOutputStream z = new ZipOutputStream(out)) {
            sums.put("db/" + Db.NAME, putFile(z, "db/" + Db.NAME, tmpDb));
            File src = new File(ctx.getFilesDir(), "sources");
            File[] files = src.listFiles();
            if (files != null) for (File f : files) if (f.isFile()) sums.put("sources/" + f.getName(), putFile(z, "sources/" + f.getName(), f));
            byte[] prefs = prefsJson(ctx).toString(2).getBytes("UTF-8");
            sums.put("settings.json", putBytes(z, "settings.json", prefs));
            man.put("sha256", sums);
            putBytes(z, "manifest.json", man.toString(2).getBytes("UTF-8"));
        } finally {
            //noinspection ResultOfMethodCallIgnored
            tmpDb.delete();
        }
    }

    static JSONObject check(Repository repo, Models.Session s) throws Exception {
        Models.Stats st = repo.stats(s.id);
        JSONObject o = new JSONObject();
        o.put("id", s.id); o.put("name", s.name); o.put("items", st.items); o.put("counted", st.counted);
        o.put("ops", repo.opCount(s.id)); o.put("sumQty", Num.plain(st.sumQty)); o.put("sumValue", Num.plain(st.sumValue));
        return o;
    }

    static JSONObject prefsJson(Context ctx) throws Exception {
        JSONObject o = new JSONObject();
        for (Map.Entry<String, ?> e : ctx.getSharedPreferences(Settings.FILE, 0).getAll().entrySet()) {
            Object v = e.getValue();
            JSONObject t = new JSONObject();
            t.put("t", v instanceof Boolean ? "b" : v instanceof Long ? "l" : v instanceof Integer ? "i" : "s");
            t.put("v", String.valueOf(v));
            o.put(e.getKey(), t);
        }
        return o;
    }

    // ------------------------------------------------------------------ validate

    /** Extracts and fully validates a backup (checksums, SQLite integrity, totals). Does NOT touch live data. */
    public static Plan validate(Context ctx, File zipFile) throws Exception {
        File dir = new File(ctx.getCacheDir(), "restore_check");
        deleteTree(dir);
        if (!dir.mkdirs()) throw new IOException("تعذر تجهيز مجلد مؤقت");
        JSONObject man;
        try (ZipFile z = new ZipFile(zipFile)) {
            ZipEntry me = z.getEntry("manifest.json");
            if (me == null) throw new IOException("الملف ليس نسخة احتياطية من SMART STOCK");
            man = new JSONObject(new String(readAll(z.getInputStream(me)), "UTF-8"));
            if (!FORMAT.equals(man.optString("format"))) throw new IOException("تنسيق النسخة الاحتياطية غير مدعوم");
            JSONObject sums = man.getJSONObject("sha256");
            for (Enumeration<? extends ZipEntry> en = z.entries(); en.hasMoreElements(); ) {
                ZipEntry e = en.nextElement();
                String n = e.getName();
                if (n.equals("manifest.json") || e.isDirectory()) continue;
                if (n.contains("..") || n.startsWith("/")) throw new IOException("مسار غير آمن داخل النسخة");
                if (!sums.has(n)) throw new IOException("ملف غير متوقع داخل النسخة: " + n);
                File target = new File(dir, n);
                //noinspection ResultOfMethodCallIgnored
                target.getParentFile().mkdirs();
                String sha;
                try (InputStream in = z.getInputStream(e); OutputStream o = new FileOutputStream(target)) { sha = copyHash(in, o); }
                if (!sha.equals(sums.getString(n))) throw new IOException("النسخة تالفة: بصمة غير مطابقة (" + n + ")");
            }
            for (java.util.Iterator<String> it = sums.keys(); it.hasNext(); ) {
                String n = it.next();
                if (!new File(dir, n).exists()) throw new IOException("ملف مفقود من النسخة: " + n);
            }
        }
        Plan p = new Plan();
        p.dir = dir;
        p.createdAt = man.optString("createdAt");
        p.appVersion = man.optString("appVersion");
        p.dbVersion = man.optInt("dbVersion");
        if (p.dbVersion > Db.VERSION) throw new IOException("النسخة من إصدار أحدث للتطبيق؛ حدّث التطبيق أولًا");
        File dbFile = new File(dir, "db/" + Db.NAME);
        SQLiteDatabase sdb = SQLiteDatabase.openDatabase(dbFile.getPath(), null, SQLiteDatabase.OPEN_READONLY);
        try {
            try (Cursor c = sdb.rawQuery("PRAGMA integrity_check", null)) {
                if (!c.moveToFirst() || !"ok".equalsIgnoreCase(c.getString(0))) throw new IOException("قاعدة البيانات داخل النسخة تالفة");
            }
            Repository r = new Repository(sdb);
            JSONArray sess = man.getJSONArray("sessions");
            for (int i = 0; i < sess.length(); i++) {
                JSONObject exp = sess.getJSONObject(i);
                Models.Session s = r.session(exp.getLong("id"));
                if (s == null) throw new IOException("جلسة مفقودة من النسخة: " + exp.optString("name"));
                JSONObject got = check(r, s);
                for (String k : new String[]{"items", "counted", "ops", "sumQty", "sumValue"})
                    if (!String.valueOf(exp.get(k)).equals(String.valueOf(got.get(k))))
                        throw new IOException("بيانات الجلسة \"" + s.name + "\" لا تطابق البصمة (" + k + ")");
                if (!new File(dir, s.sourceFile).exists()) throw new IOException("ملف Excel الأصلي للجلسة \"" + s.name + "\" مفقود");
                SessionCheck sc = new SessionCheck();
                sc.id = s.id; sc.name = s.name; sc.items = got.getInt("items"); sc.counted = got.getInt("counted");
                sc.ops = got.getInt("ops"); sc.sumQty = got.getString("sumQty"); sc.sumValue = got.getString("sumValue");
                p.sessions.add(sc);
            }
        } finally {
            sdb.close();
        }
        return p;
    }

    // ------------------------------------------------------------------ apply

    /** Replaces live data with a validated plan. A safety copy of the current data is written first. */
    public static void apply(Context ctx, Plan plan, String appVersion) throws Exception {
        File safety = new File(ctx.getFilesDir(), "pre_restore_backup.zip");
        try (OutputStream o = new FileOutputStream(safety)) { create(ctx, o, appVersion); }
        Db.reset();
        File live = ctx.getDatabasePath(Db.NAME);
        for (String sfx : new String[]{"-journal", "-wal", "-shm"}) //noinspection ResultOfMethodCallIgnored
            new File(live.getPath() + sfx).delete();
        copyFile(new File(plan.dir, "db/" + Db.NAME), live);
        File src = new File(ctx.getFilesDir(), "sources");
        File newSrc = new File(plan.dir, "sources");
        deleteTree(src);
        //noinspection ResultOfMethodCallIgnored
        src.mkdirs();
        File[] fs = newSrc.listFiles();
        if (fs != null) for (File f : fs) copyFile(f, new File(src, f.getName()));
        File prefs = new File(plan.dir, "settings.json");
        if (prefs.exists()) {
            JSONObject o = new JSONObject(new String(readAll(new FileInputStream(prefs)), "UTF-8"));
            SharedPreferences.Editor ed = ctx.getSharedPreferences(Settings.FILE, 0).edit().clear();
            for (java.util.Iterator<String> it = o.keys(); it.hasNext(); ) {
                String k = it.next();
                JSONObject t = o.getJSONObject(k);
                String v = t.getString("v");
                switch (t.getString("t")) {
                    case "b": ed.putBoolean(k, Boolean.parseBoolean(v)); break;
                    case "l": ed.putLong(k, Long.parseLong(v)); break;
                    case "i": ed.putInt(k, Integer.parseInt(v)); break;
                    default: ed.putString(k, v);
                }
            }
            ed.commit();
        }
        // re-verify the now-live data against the manifest
        Repository repo = new Repository(Db.get(ctx));
        for (SessionCheck sc : plan.sessions) {
            Models.Session s = repo.session(sc.id);
            Models.Stats st = repo.stats(sc.id);
            if (s == null || st.items != sc.items || st.counted != sc.counted || !Num.plain(st.sumQty).equals(sc.sumQty) || !Num.plain(st.sumValue).equals(sc.sumValue))
                throw new IOException("فشل التحقق بعد الاستعادة. توجد نسخة أمان من بياناتك السابقة: pre_restore_backup.zip");
        }
        deleteTree(plan.dir);
    }

    // ------------------------------------------------------------------ io helpers

    static String putFile(ZipOutputStream z, String name, File f) throws Exception {
        z.putNextEntry(new ZipEntry(name));
        String sha;
        try (InputStream in = new FileInputStream(f)) { sha = copyHash(in, z); }
        z.closeEntry();
        return sha;
    }

    static String putBytes(ZipOutputStream z, String name, byte[] b) throws Exception {
        z.putNextEntry(new ZipEntry(name));
        z.write(b);
        z.closeEntry();
        return hex(MessageDigest.getInstance("SHA-256").digest(b));
    }

    static String copyHash(InputStream in, OutputStream out) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] buf = new byte[1 << 16];
        int n;
        while ((n = in.read(buf)) > 0) { md.update(buf, 0, n); out.write(buf, 0, n); }
        return hex(md.digest());
    }

    public static String sha256(File f) throws Exception {
        try (InputStream in = new FileInputStream(f)) { return copyHash(in, new java.io.ByteArrayOutputStream() { @Override public synchronized void write(byte[] b, int o, int l) {} }); }
    }

    static String hex(byte[] d) {
        StringBuilder b = new StringBuilder();
        for (byte x : d) b.append(String.format(java.util.Locale.US, "%02x", x));
        return b.toString();
    }

    static byte[] readAll(InputStream in) throws IOException {
        try (InputStream s = in) {
            java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n;
            while ((n = s.read(buf)) > 0) b.write(buf, 0, n);
            return b.toByteArray();
        }
    }

    public static void copyFile(File from, File to) throws IOException {
        //noinspection ResultOfMethodCallIgnored
        to.getParentFile().mkdirs();
        File tmp = new File(to.getPath() + ".tmp");
        try (InputStream in = new FileInputStream(from); FileOutputStream out = new FileOutputStream(tmp)) {
            byte[] buf = new byte[1 << 16]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.getFD().sync();
        }
        if (to.exists() && !to.delete()) throw new IOException("تعذر استبدال " + to.getName());
        if (!tmp.renameTo(to)) throw new IOException("تعذر حفظ " + to.getName());
    }

    public static void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        File[] k = f.listFiles();
        if (k != null) for (File c : k) deleteTree(c);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }
}
