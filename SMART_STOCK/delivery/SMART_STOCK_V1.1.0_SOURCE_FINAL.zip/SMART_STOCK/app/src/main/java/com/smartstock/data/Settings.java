package com.smartstock.data;

import android.content.Context;
import android.content.SharedPreferences;

/** App preferences (included in backups). */
public final class Settings {
    private Settings() {}
    public static final String FILE = "settings";

    static SharedPreferences p(Context c) { return c.getSharedPreferences(FILE, 0); }

    public static long activeSession(Context c) { return p(c).getLong("active_session", -1); }
    public static void setActiveSession(Context c, long id) { p(c).edit().putLong("active_session", id).commit(); }

    public static boolean sound(Context c) { return p(c).getBoolean("sound", true); }
    public static void setSound(Context c, boolean v) { p(c).edit().putBoolean("sound", v).apply(); }

    public static boolean vibrate(Context c) { return p(c).getBoolean("vibrate", true); }
    public static void setVibrate(Context c, boolean v) { p(c).edit().putBoolean("vibrate", v).apply(); }

    public static String currency(Context c) { return p(c).getString("currency", ""); }
    public static void setCurrency(Context c, String v) { p(c).edit().putString("currency", v == null ? "" : v.trim()).apply(); }

    public static boolean torch(Context c) { return p(c).getBoolean("torch", false); }
    public static void setTorch(Context c, boolean v) { p(c).edit().putBoolean("torch", v).apply(); }

    /** Above this quantity the app asks for confirmation (protects against a barcode typed into the quantity field). */
    public static int largeQty(Context c) { return p(c).getInt("large_qty", 1000); }
    public static void setLargeQty(Context c, int v) { p(c).edit().putInt("large_qty", v).apply(); }
}
